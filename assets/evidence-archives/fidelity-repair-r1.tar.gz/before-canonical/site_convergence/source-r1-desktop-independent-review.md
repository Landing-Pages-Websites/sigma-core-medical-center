# Sigma Core Medical: source-r1 independent desktop review

**All 10 designed interior routes were inspected. Four are visually close to their truthful references; five need composition repairs; regenerative medicine remains open for successor art-direction approval. No registry edge flag is certified by this report.**

## Evidence and limits

- Target recorded in navigation receipts: `https://sigma-core-medical-review-9822bazl7-mega-websites.vercel.app`. All 10 route receipts record HTTP 200 and successful full-page captures at desktop 1440 × 900, DPR 1.
- I visually inspected every supplied `*-full.png`, every corresponding `design_refs/pages/<page>/page.png`, and 59 section-lower-seam crops. These are independent judgments of **existing captures**, not newly acquired browser screenshots. No shared browser tab was reopened or modified.
- Full captures: [`captures/source-r1/desktop_1440x900/`](captures/source-r1/desktop_1440x900/). Lossless, native-width seam sheets: [`captures/source-r1/desktop-independent-seams/`](captures/source-r1/desktop-independent-seams/). Each sheet labels the source PNG row interval. Crops preserve screenshot pixels; their cut-off tops/bottoms are crop boundaries, not page defects.
- Reference scope follows `design_refs/pages/SITE-DESIGN-PLAN.md`, which selects **B, The Forward Standard**. Services and the five medical detail composition maps explicitly retain historical native frames while defining source-safe code successors with `SOURCE_RECONCILED_VISUAL_PENDING`. Missing unsupported clinic photographs, live calendars, clinical approvals and source endorsements are **not** restoration instructions. Visual changes still require review; truthful source reconciliation is not convergence approval.
- “Loaded” below means the visible screenshot contains rendered type, geometry and expected visible media without an apparent error page, blank section, broken-image placeholder or loading skeleton. It does not prove lazy-loading behavior, original asset identity, font-file/weight correctness, functionality, medical/legal approval or mobile quality.
- No source, registry, task, PR or deployment was edited. All 14 registry edge flags are to remain false. This desktop-only report does not promote them or constitute Site Review/go-live approval.

## Route findings

### `/services`
Evidence: `services-full.png` (1440 × 4387), `services-lower-seams.png`; reference `services/page.png` plus its successor composition map.

- **Integrity:** Visibly loaded, including the walking figure and active couple.
- **Convergence:** **Needs repair.** Navy/blue rhythm and neuropathy priority survive, but the successor remains substantially simpler than the native composition. The hero's category rail has descriptive support only for Pain relief; the other three large tiles read comparatively unfinished.
- **Lower seams inspected:** Hero 858; neuropathy feature 1794; service navigation 2581; next-step section 3263; final CTA 4064. The pale other-care band does have breathing room below its links; it is not a text-to-boundary collision. However, the four link arrows are visibly cut by their angled card edges. The hero rail deliberately meets the blue band, with labels safely above it. Navigation, next-step and final-CTA closes show separation from following content.
- **Unresolved:** Repair the clipped arrows and improve category-rail hierarchy. Reconcile final “Book an appointment” presentation with the clearly unavailable booking state. Do not restore the fictional facility scenes to obtain fidelity.

### `/services/neuropathy`
Evidence: `services-neuropathy-full.png` (1440 × 5372), corresponding seam sheet; reference `neuropathy/page.png` and successor map.

- **Integrity:** Visibly loaded, including the walking subject.
- **Convergence:** **Needs repair.** The hero subject is enlarged and moved toward the image's angled left edge compared with the reference. The information architecture remains legible, but tall, sparsely filled orientation cards and the goals sidebar lose the reference's density and balance.
- **Lower seams inspected:** Hero 831; orientation 1522; goals 2366; preparation 2969; FAQ 3867; question sheet 4504; medical sources 5049. The third hero step card ends flush against the next blue field, unlike the reference's closing separation. The hero CTA's right outline/tip is visibly clipped. In the question-sheet close, “Online booking is not available yet” begins on the angled blue edge with essentially no inset. The remaining closes have visible space after their semantic content, including the FAQ-to-question-sheet same-color transition.
- **Unresolved:** Repair CTA clipping, step-card closing clearance and the question-sheet status inset; rebalance the oversized empty card/sidebar areas. Preserve the unavailable-booking and source-limit disclosures.

### `/services/pain-relief`
Evidence: `services-pain-relief-full.png` (1440 × 6656), corresponding seam sheet; reference `pain-relief/page.png` and successor map.

- **Integrity:** Visibly loaded, including all three lifestyle scenes. Loaded media is not the same as an acceptable crop.
- **Convergence:** **Needs repair.** The code-safe hero/navigation substitutions are intentional, but the knee section's oblique cards visibly cut into their own left text edges. The shallow walking banner removes the subject's head and feet. The low-back scene tightly crops the head at the top, while the neck scene omits the book/hands that make the reference's activity legible.
- **Lower seams inspected:** Hero 827; concern navigation 1566; knee 2235; low back 3135; neck 3871; decisions 4573; FAQ 5171; preparation 5776; sources 6333. The knee banner's lower crop is the material issue, not a missing gap to the next section. Other closes retain visible clearance. The low-back source-link arrow wraps onto a separate line in the sources grid, a small finishing issue.
- **Unresolved:** Inset semantic text inside the knee card polygons; restore activity-readable lifestyle crops using supported assets. Keep knee, low-back, neck and joint information together on this parent route. Do not reproduce the reference's unsupported approval claims.

### `/services/hormone-optimization`
Evidence: `services-hormone-optimization-full.png` (1440 × 5341), corresponding seam sheet; reference `hormone-optimization/page.png` and successor map.

- **Integrity:** Visibly loaded; the hero image is present but does not reproduce the reference's subject/composition.
- **Convergence:** **Needs repair.** The reference shows the note-taking man's face and writing activity; the build predominantly shows his back/head at the left crop edge. The orientation section has a large empty upper-left blue field and a tall, nearly empty lower-right navy block. This is lost compositional balance, not evidence of an unloaded image.
- **Lower seams inspected:** Hero 1043; orientation 1920; goals 2629; responsible next step 3263; FAQ 3959; status close 4535; sources 5018. No semantic content is cut by these section boundaries. Goals, responsible-next-step and FAQ closes have breathing room. The status module has only a narrow outer blue bottom band, though its inner semantic content is inset.
- **Unresolved:** Recover the hero's face/activity relationship using supported media; restructure the orientation voids rather than preserving space formerly occupied by unsupported photography. Final status/source modules are readable, but their flatter successor treatment still lacks visual approval.

### `/services/pelvic-floor-incontinence`
Evidence: `services-pelvic-floor-incontinence-full.png` (1440 × 5307), corresponding seam sheet; reference `pelvic-floor-incontinence/page.png` and successor map.

- **Integrity:** Visibly loaded; the seated lifestyle image is not a placeholder.
- **Convergence:** **Needs repair.** The seated subject is pushed into the right edge and tightly cropped compared with the reference's complete person/chair scene. Private Orientation replaces photographic framing with two very tall, mostly empty dark towers, weakening the central message. What To Expect also carries excessive empty field around a sparse successor panel.
- **Lower seams inspected:** Hero 927; private orientation 1670; concerns/goals 2392; expectations 3085; FAQ 3841; status close 4454; sources 4984. All retain separation after the last meaningful text/link. The expectations close is over-spaced rather than crowded. FAQ, status and source closes have no apparent clipped text or controls.
- **Unresolved:** Correct subject/chair cropping and shorten or redistribute the empty orientation/expectation structures. Preserve the restrained privacy and booking qualifiers; do not restore unverified confidentiality or treatment promises from historical refs.

### `/services/regenerative-medicine`
Evidence: `services-regenerative-medicine-full.png` (1440 × 5770), corresponding seam sheet; reference `regenerative-medicine/page.png` and successor map.

- **Integrity:** Visibly loaded. The image-free hero's layered geometry is intentional.
- **Convergence:** **Open, successor art-direction approval needed.** The category-first hero, five consultation prompts, comparison sequence and evidence-boundary panel are coherent and readable. They differ materially from the retained native reference's photo-led layers. That difference is documented, but the map still states visual approval is pending.
- **Lower seams inspected:** Hero 928; category orientation 1670; consultation questions 2564; decisions 3326; FAQ 4151; status close 4821; sources 5447. No visible lower-seam clipping or text collision was found. The attached question-card/support-band join reads intentionally continuous. Later links and source-review grid close with visible clearance.
- **Unresolved:** Director approval of the source-safe composition, particularly uniform question-card heights and flatter section transitions. No new desktop clipping defect identified. Do not replace pending source status with the historical “reviewed by clinician” claim.

### `/about`
Evidence: `about-full.png` (1440 × 4944), `about-lower-seams.png`; reference `about/page.png`.

- **Integrity:** Visibly loaded. **Geometry binding caveat:** the saved DOM receipt reports height 4989, 45 px taller than the PNG. Later painted boundaries also occur about 45 px before their recorded DOM positions. This report uses the PNG's painted boundaries, not stale geometry as proof.
- **Convergence:** **Visually close, desktop only.** Dominant three-line statement, electric emphasis/steps, neuropathy-first purpose, truthful location/team gates and care-principles split retain the reference's hierarchy. Care-principle headings wrap differently, without clipping.
- **Lower seams inspected:** Hero 934; purpose/grounded-principles close around 1813; location 2548; care 3328; team transition around 3819; final CTA/footer transition around 4621. Purpose and team transitions share the following field color, so these are flow transitions rather than independent painted edges. Location and care closes maintain breathing room; the final status panel and bracket remain separate from the footer.
- **Unresolved:** Reacquire matching screenshot/geometry receipts before quantitative edge certification. No additional desktop clipping defect found. This is not a registry pass.

### `/educational-guide`
Evidence: `educational-guide-full.png` (1440 × 2557), corresponding seam sheet; reference `educational-guide/page.png`.

- **Integrity:** Visibly loaded. “Resource unavailable” and “No active form” are designed states, not loading failures.
- **Convergence:** **Visually close, desktop only.** Status-first hero, source table, blocked collection panel and privacy note reproduce the truthful reference's composition and reading order.
- **Lower seams inspected:** Hero/source-details rail 690, including its navy-to-blue change at 590; source summary 1300; blocked collection 1834; privacy/footer 2234. Controls and status copy remain inside their surfaces; each close has visible separation. The lower starting-point band is inset from the next charcoal field.
- **Unresolved:** No material desktop section/seam defect identified. Resource/delivery and privacy approvals remain operational gates, not visual failures and not permission to activate collection.

### `/book`
Evidence: `book-full.png` (1440 × 2342), corresponding seam sheet; reference `book/page.png`.

- **Integrity:** Visibly loaded. No calendar is expected in this truthful unavailable state.
- **Convergence:** **Visually close, desktop only.** Large scheduling statement, geometric right accent, angled blue calendar-status field, service/contact alternatives and legal-content gate retain the reference's hierarchy. Vertical depth is more compact than the native bitmap.
- **Lower seams inspected:** Hero slope approximately 597–706; calendar slope 1358–1439; privacy/footer 2019. Slopes stay clear of text/actions. Contact qualification and lower decorative steps do not collide with the cream transition; legal status closes with ample room.
- **Unresolved:** No material desktop clipping defect found. Confirm compacted spacing in fresh viewport evidence before formal edge approval. Booking/legal readiness remains gated.

### `/contact`
Evidence: `contact-full.png` (1440 × 3639), corresponding seam sheet; reference `contact/page.png`.

- **Integrity:** Visibly loaded. Clinic-photo text links to Home intentionally; this is not a failed local photo slot.
- **Convergence:** **Visually close, desktop only.** Contact-status hierarchy, three-row details table, Before You Visit split and final information-navigation list track the truthful reference. The last section is relatively spacious but follows the reference's same asymmetry.
- **Lower seams inspected:** Hero slope approximately 811–918; details slope 1600–1646; Before You Visit painted boundary 2502; final navigation/footer 3316. These painted limits differ from several DOM section boxes. All visible content remains clear of the sloped/flat transitions, including the last scheduling-status qualifier.
- **Unresolved:** Use painted edge positions, not section-box bottoms alone, for subsequent certification. No additional desktop clipping defect identified. Address/contact/hours verification remains separate.

## Next owner and action

**Sigma Core site builder:** repair the five identified composition/clipping routes, prioritizing neuropathy's hero/question-sheet edges, services' arrows, pain-relief's semantic polygons/crops, and the hormone/pelvic hero and empty-field balance. Preserve supported assets and all truthful gates. **WEB Director:** judge the documented code successors, including regenerative medicine, against source-safe art direction rather than demanding restoration of unsupported native content. Then obtain fresh desktop/mobile evidence and a separate quantitative painted-edge review before any registry promotion.
