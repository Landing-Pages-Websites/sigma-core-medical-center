# Sigma Core Medical: source-r1 independent mobile visual review

**Outcome: all 10 designed interior routes have visible, loaded full-page evidence, but mobile visual convergence is not approved. Capture-to-geometry integrity and several image-composition/art-direction issues remain unresolved. Registry flags must stay false.**

Reviewed 2026-10-03. This is an evidence-only review of the supplied immutable-preview captures. No registry, source, task, PR, or deployment was edited. This report does not grant launch approval or verify interaction behavior.

## Scope and evidence method

- Preview recorded in navigation evidence: `https://sigma-core-medical-review-9822bazl7-mega-websites.vercel.app`.
- Screenshot base: `captures/source-r1/mobile_390x844/`, relative to this report's directory.
- Approved reference base: `../design_refs/pages/`. Compared each route against its canonical `page.png`, not `page-draft.png`.
- Reviewed all 10 full PNGs visually from header through final footer, all 10 section sheets visually, and targeted native-size crops for the hormone hero, pain/knee section, and neuropathy question-sheet/source seam. The sheets contain the supplied 59 section crops. Every section transition is enumerated below.
- Read all 10 geometry JSON files for CSS section/content bounds. Those measurements are corroborating evidence only, not a visual verdict.
- All 10 navigation records report HTTP 200. All 10 full PNGs decoded and verified successfully. Every full image visibly contains real page text/layout and a completed footer, with no browser error page, broken-image indicator, blank loading frame, or visibly truncated final footer.
- References are desktop compositions, not mobile comps. Responsive stacking is acceptable. Review asks whether imagery, hierarchy, palette distribution, angular language, subject prominence, and section rhythm survive the translation, not whether desktop columns remain side by side.
- `SITE-FLOW-CHECK.md` identifies the selected family as Direction B, **The Forward Standard**, and explicitly excludes global navigation/footer from reference frames. Header/footer are therefore reviewed for visible integrity and responsive presentation, not pixel fidelity to an absent reference.
- Truthful unavailable booking, resource, team, location, and source-review states take precedence over reference-image microcopy. Do not restore invented appointment availability, clinical approval, providers, or unverified clinic imagery to solve fidelity differences.

## Shared unresolved evidence issue

**E1, capture/geometry mismatch, applies to all 10 routes.** The directory, PNG widths, and geometry `viewport.width` say 390; nevertheless every geometry file reports document width 375 and all section right edges are 375. Most geometry document heights also disagree with the full PNG height. This is not evidence of horizontal overflow: sampled content bounds are inside the reported 375px document. It is evidence that the JSON bounds cannot be treated as the exact same layout as the 390px screenshots.

For example, `/about` geometry describes a 6066px document and hero bottom at y=911.28, while its full screenshot is 5850px tall and the visible hero/blue-band boundary is materially earlier. `/services` geometry places its first H2 in a two-line-height box, while the full screenshot visibly shows “Neuropathy comes first.” on one line. Do not use these JSON y-values as exact pixel coordinates for the rendered seam images.

The supplied section crops/sheets also sometimes start partway through headings. Full images show those headings complete. That is a crop/evidence-registration issue, not automatically a website clipping defect. White filename-label strips in sheets are presentation labels, not page seams.

**Next action:** capture owner should obtain full image, section/seam windows, viewport/document dimensions, and geometry from one unchanged 390×844 layout state. Until reconciled, there is no certified CSS-to-pixel edge verdict, even where the visible seam itself looks clean.

### Artifact integrity ledger

SHA-256 values below are 16-character prefixes identifying the reviewed full PNGs. Heights are actual file dimensions, not JSON assertions.

| Route | Full image | PNG size | JSON scroll height | CSS content x bounds | SHA-256 prefix |
|---|---|---:|---:|---:|---|
| `/services` | `services-full.png` | 390×6234 | 6296 | 18–357 | `52cfc9df648c5e0d` |
| `/services/neuropathy` | `services-neuropathy-full.png` | 390×8530 | 8646 | 18–357 | `a37a82a38b8f0241` |
| `/services/pain-relief` | `services-pain-relief-full.png` | 390×10095 | 10116 | 16–359 | `a0bf76476ef0a3b1` |
| `/services/hormone-optimization` | `services-hormone-optimization-full.png` | 390×8701 | 8858 | 16–359 | `c405f3a4dd63da94` |
| `/services/pelvic-floor-incontinence` | `services-pelvic-floor-incontinence-full.png` | 390×7177 | 7241 | 16–359 | `30fd9a45feb81f85` |
| `/services/regenerative-medicine` | `services-regenerative-medicine-full.png` | 390×9409 | 9573 | 16–359 | `f43ce9f26f5db64a` |
| `/about` | `about-full.png` | 390×5850 | 6066 | 24–351 | `4d4a2fcb3531d726` |
| `/contact` | `contact-full.png` | 390×3316 | 3343 | 20–355 | `db23588640e7a9ab` |
| `/book` | `book-full.png` | 390×2277 | 2277 | 24–351 | `323dd4f786658b86` |
| `/educational-guide` | `educational-guide-full.png` | 390×3698 | 3695 | 18–357 | `f1972201494d091f` |

## Route reviews

### 1. `/services`

**Loaded integrity:** full image and five-section sheet loaded visibly; header, all service groups, both lower conversion modules, walnut rail, and complete footer are present. Geometry content bounds stay inside the reported 375px document; E1 remains.

**Visual convergence: partial.** The navy/electric-blue/mineral sequence, bracketed headlines, angular links, primary neuropathy emphasis, architectural walker image, and waterfront runners survive. The neuropathy feature remains clearly more prominent than the four secondary categories. The actual runners are large enough to read as the subject, not a vague background.

The reference's large clinic-led hero and lower photographic modules are replaced with small geometric surfaces. Service icons/material details are simplified substantially. This is not just stacking desktop columns: the rendered route is much more card/text-led. Since reference clinic scenes are not automatically verified facility photography, restoration is not authorized by this review; design-owner acceptance of the revised visual composition remains unresolved.

**Visible seam/edge inspection:**
- Header → hero: clean blue divider, complete title, usable gutters.
- Within hero: bracketed copy → blue neuropathy wedge → geometric aperture → 2×2 service links is legible. Service grid terminates tightly at the next blue band, without a visible stray gutter or text collision.
- Hero → neuropathy feature: clean navy/blue boundary.
- Feature image → navy neuropathy panel → pale “Other areas of care” tile group: aligned, subject visible, no overlay on link labels.
- Neuropathy → service navigation: clean blue-to-light transition and bracketed heading.
- Navigation → how-it-works: clean light-to-charcoal transition; secondary cards stay inside page gutters.
- How-it-works → form/CTA: charcoal-to-navy transition is intact. The appointment button attached to the geometric panel is contained, but its right tip is very close to the panel edge.
- Form/CTA → walnut rail → footer: intact, no visible bottom crop or overlap.

**Unresolved defects:** E1; **V1** revised low-imagery composition has not visibly converged with the reference; **V2** two prominent “Book an appointment” controls still read as an available action even while nearby copy says booking integration is unavailable. The screenshot cannot establish their destination, but the visual action/status conflict is real. Prefer status-led labeling consistent with `/book`, subject to the approved content contract. No missing/broken image claim is made.

### 2. `/services/neuropathy`

**Loaded integrity:** full image, seven-section sheet, and native question-sheet/source crop viewed. Header, outdoor hero image, every orientation/FAQ/question module, sources, rail, and complete footer are visible. E1 remains.

**Visual convergence: partial, with a sound mobile hero subject.** The outdoor walker is recognizably the same movement-led subject as the reference and remains large, with legs/feet visible. The image is not buried behind a scrim. Navy/blue/light/charcoal rhythm and angled light/dark orientation panels are retained. Copy changes explicitly keep source and clinical-review limitations visible.

Lower reference compositions are substantially flattened: three goal plaques are small slanted rows, what-to-expect becomes a text/geometry module, FAQ becomes fully expanded cards, and the booking module becomes a local-notes question sheet. Removing unverified facility scenes and unavailable booking is defensible, but that does not demonstrate approval of the replacement visual composition.

**Visible seam/edge inspection:**
- Header → hero: intact; long H1 wraps without horizontal truncation.
- Hero image → three goal strips: clean layering, no text on the subject.
- Hero → visitor orientation: clean navy/blue join.
- Orientation text/callout → light/dark comparison panels: readable separate panels; angled corners do not clip body copy.
- Orientation → goals/decision factors: clean blue/light boundary.
- Slanted goal rows → dark question panel: tightly connected, no visible collision.
- Goals → what-to-expect: clean light/charcoal boundary.
- What-to-expect → FAQ: clean charcoal/navy boundary.
- FAQ → question-sheet section: same navy canvas, clear spacing rather than a missing seam.
- Question-sheet panel → blue source-action strip → medical sources: native crop confirms complete button label and clean navy/light boundary. Crop begins inside the heading, but the full image shows the whole heading.
- Medical sources → rail/footer: intact.

**Unresolved defects:** E1; **V3** lower-page card/geometry replacements are not yet visibly converged with the reference's richer image/material compositions. There is no visible broken asset or text-overlap defect. Do not restore unsupported source-review or booking assertions from the ref.

### 3. `/services/pain-relief`

**Loaded integrity:** full image, nine-section sheet, and native knee crop viewed. All knee/back/neck content, decision checklist, FAQ, preparation panel, source groups, rail, and footer are visible. E1 remains.

**Visual convergence: partial.** Page retains distinct light knee, charcoal back, navy neck, and blue decision sections, rather than cloning the same block three times. Gardening and reading subjects remain recognizable. The reference's photo-led branch-map hero is replaced by a “Movement is personal” graphic, and concern navigation is now text cards without the large photo apertures. These are material art-direction changes, not merely responsive stacking.

**Visible seam/edge inspection:**
- Header → hero: clean divider and complete H1.
- Hero → pain navigation: clean navy/blue boundary.
- Within navigation: blue field transitions into light behind the stacked cards. Cards stay intact across this color change, with no white slit or cut text.
- Navigation → knee: same light canvas, a generous pause but an unambiguous next H2.
- Knee image → attached blue question button: physically aligned, but the image composition is defective as described below.
- Knee → low back: clean light/charcoal seam.
- Back CTA panel → gardening image → disclaimer: contained, no overlap.
- Low back → neck: clean charcoal/navy seam.
- Neck image → question rows: clean subject/panel separation; rows fit the gutters.
- Neck → decision factors: clean navy/blue seam.
- Decision factors → FAQ: clean blue/light seam.
- FAQ answer panel → blue “Make it personal” block: flush and readable.
- FAQ → preparation: clean light/charcoal seam.
- Preparation → medical sources: clean charcoal/navy seam; three in-page return links fit one row.
- Sources → rail/footer: intact.

**Unresolved defects:** E1; **V4** knee photography is visibly soft and cropped to a walking torso/legs with the feet cut off at the bottom. The reference's walking composition shows the stride/feet clearly. Native crop confirms this is not merely full-image normalization. It weakens the movement-specific visual role. Builder should preserve the walking stride and use a sufficiently resolved approved asset/crop; do not replace it with an unverified clinic subject. **V5** photo-led hero and concern-navigation composition have been reduced to generic geometry/text; replacement direction needs explicit acceptance. No seam overlap is observed.

### 4. `/services/hormone-optimization`

**Loaded integrity:** full image, seven-section sheet, and native hero crop viewed. All status/FAQ/source modules, rail, and footer are visible. E1 remains.

**Visual convergence: materially incomplete.** Navy/blue/light/charcoal sequence, selective italic serif, stepped marks, and a writing-at-home scene connect to the reference family. However, the hero crop loses the reference's main human composition. Orientation, goal columns, responsible-next-step scene, booking panel, and source block are simplified into long stacked boxes. This route is readable but considerably less composed than the approved reference.

**Visible seam/edge inspection:**
- Header → hero: clean; stepped motif is restricted to the upper-right corner, not across the title.
- Hero button → photograph → three information strips → italic caveat: separate readable modules.
- Hero → orientation: clean navy/blue join.
- Orientation pale information block → small goals strip → charcoal general/personal distinction → navy question link: connected panels, no text collision.
- Orientation → goals: clean blue/light boundary.
- Four goal rows → dark italic question panel → blue links: clean stack; no clipped labels.
- Goals → responsible-next-step: clean light/charcoal boundary.
- Approval details → consultation clarity → blue booking-status panel: full-height visible stack, no overlap.
- Responsible-next-step → FAQ: clean charcoal/navy join.
- FAQ → booking status: clean navy/blue transition.
- Within status card: diagonal blue corner approaches the paragraph/italic line but does not visibly cover text.
- Booking status → medical sources: clean blue/light boundary.
- Sources → rail/footer: intact.

**Unresolved defects:** E1; **V6** hero crop cuts off most of the man's face/head at the left image edge. In the reference the face, writing hands, and notebook form the visual subject. Native crop shows a partial back/arm beside furnishings, making the image feel like an interchangeable room backdrop. Correct object positioning/aspect/asset framing while preserving the approved scene. **V7** lower visual hierarchy is now repetitive rectangular status cards rather than the reference's differentiated stepped/material and image compositions; approval/convergence remains unresolved. Do not restore unavailable appointment actions or invented clinical source approval.

### 5. `/services/pelvic-floor-incontinence`

**Loaded integrity:** full image and seven-section sheet viewed. All private-orientation, concerns, FAQ/status, source card, rail, and footer elements are present. E1 remains.

**Visual convergence: partial.** Dignified outdoor subject, dark/light layered hero, selective serif privacy line, navy/blue/mineral fields, angled panels, and restrained stepped motifs are recognizable. The reference's lower image-led concerns/FAQ/CTA material compositions become text/status cards. Honest clinical/privacy limitations are visible; they should not be replaced with the reference's unsupported confidentiality assurances.

**Visible seam/edge inspection:**
- Header → hero: clean divider and intact title.
- Hero layered backdrop → outdoor photograph → privacy caption: caption is contained and readable; photo/caption join is intentional.
- Hero → private orientation: clean navy/blue boundary.
- Orientation side-note replacements → main copy → link/callout: orderly vertical stack, all text inside angled bounds.
- Private orientation → concerns/goals: clean blue/light join.
- Concerns → dark “What matters most” panel: intact angled top, readable prompts.
- Concerns → what-to-expect: clean light/charcoal join.
- What-to-expect → FAQ: clean charcoal/navy join.
- Four FAQ cards → limitations box → service button: no edge collision.
- FAQ → booking status: clean navy/blue join.
- Nested “Bring your questions” panel: complete inset border and readable text.
- Booking status → source: clean blue/light join.
- Source → rail/footer: intact.

**Unresolved defects:** E1; **V8** hero crops the seated subject against the right edge, cutting part of the head/shoulder and much of the chair. The person remains recognizable, so this is a moderate composition issue rather than a missing subject, but the reference gives the seated person more complete framing. **V9** lower-page replacements do not establish acceptance of the much less photographic, less differentiated visual direction. No visible text clipping or failed image load is observed.

### 6. `/services/regenerative-medicine`

**Loaded integrity:** full image and seven-section sheet viewed. Every category/consultation/decision/FAQ/status/source section, rail, and final footer is visible. E1 remains.

**Visual convergence: materially incomplete.** Color order and angular/stepped graphic vocabulary survive, and specific offerings remain correctly unverified. The reference's large photo-led hero, dimensional consultation columns, connected decision composition, FAQ image aperture, and final CTA are replaced almost entirely by geometry and flat stacked cards. The rendered page is coherent, but it no longer carries much of the approved composition's visual richness. There is no photographic subject to assess in the rendered hero.

**Visible seam/edge inspection:**
- Header → hero: clean divider and complete long title.
- Hero → inset category graphic: readable, no text on decorative outlines.
- Hero → category orientation: clean navy/blue boundary.
- Slanted light category panel → outline link → dark category-boundary panel: all contained.
- Category → consultation questions: clean blue/light join.
- Five consultation cards → dark summary → blue links: intact; angled card tops do not cut text.
- Consultation → decision factors: clean light/charcoal join.
- Decision stack → outline service links: readable; no detached or overlapping blocks.
- Decision factors → FAQ: clean charcoal/navy seam.
- FAQ rows → service links → large slanted source-status panel: intact, though this creates a long same-color stack.
- FAQ → booking status: clean navy/blue join.
- Booking panel → darker conversation panel: flush silver divider and complete copy.
- Booking → sources: clean blue/light join.
- Source status → three review cards → rail/footer: intact.

**Unresolved defects:** E1; **V10** almost complete substitution of approved photographic/material compositions with flat cards/geometry has not visually converged. Design owner must accept a truthful replacement composition or supply authorized imagery and an implementation target. Do not reintroduce reference-image assertions such as “Reviewed by clinician” or FDA approval to imitate the pixels.

### 7. `/about`

**Loaded integrity:** full image and six-section sheet viewed. Hero, mission/principles, location gate, team gate, status close, rail, and complete footer are visible. E1 is particularly material here because of the 216px height mismatch.

**Visual convergence: close responsive translation, not certified.** Compared to the canonical About ref, the stepped hero, blue neuropathy-first band, navy mission band, pale principles grid, bracketed location state, charcoal care principles, pale decision panel, navy team gate, and white booking-status slab are all recognizable. The honest no-team/no-location/no-booking treatment matches this ref, not an obsolete facility-heavy concept.

**Visible seam/edge inspection:**
- Header → hero: clean divider and complete title. Blue emphasis on navy is visibly subdued relative to white copy; contrast was not measured here.
- Hero → blue neuropathy band: clean join with stepped lower-right motif terminating in the band.
- Within clinic-purpose: blue band → navy mission → pale 2×2 principles: clean separations, no overlapping controls.
- Clinic-purpose → location state: same pale field, a deliberate generous pause.
- Location bracket → dark status slab → underlined status link: contained and readable.
- Location → care principles: clean pale/charcoal join.
- Principles → cut-corner pale decision slab: no sliver, text fits the slab.
- Care principles → team gate: clean pale/navy join.
- Team → final goals/status section: same navy canvas with clear spacing, no missing content.
- White unavailable-booking slab → walnut rail → footer: intact; bracket remains outside copy.

**Unresolved defects:** E1. No additional definite layout/seam defect identified from visible evidence. Hero blue-on-navy emphasis should receive measured contrast verification before accessibility approval; this review does not assert a numerical contrast failure. No visual PASS or registry promotion is granted.

### 8. `/contact`

**Loaded integrity:** full image and four-section sheet viewed. Status-led hero, contact rows, visiting-information gate, clinic-photo link, lower information paths, rail, and complete footer are visible. E1 remains.

**Visual convergence: close responsive translation, not certified.** Canonical reference already uses location/contact pending states. Navy hero, diagonal blue transition, rule-separated status rows, pale “Before you visit” area, angular navy information card, serif “Clinic photo” subheading, and charcoal closing paths match the visual family. Moving the visit card before the clinic-photo note is a sensible readable stack. The absence of an actual photo on this route agrees with the canonical reference's link-to-Home treatment.

**Visible seam/edge inspection:** header/hero divider clean; hero → contact rows diagonal clean; contact rows → pale visit area cut edge clean; visit card and photo link both fit gutters; pale → charcoal close clean; close → walnut rail/footer clean. Arrow on the long Home-photo link is separated to the right and does not collide with the two-line label.

**Unresolved defects:** E1. No additional definite visible clipping, overlap, broken-image, or seam defect identified. Unconfirmed contact/location facts are operational gates, not visual defects to solve by inventing data. No visual PASS or registry promotion is granted.

### 9. `/book`

**Loaded integrity:** full image and three-section sheet viewed. Honest unavailable-booking hero, calendar-pending area, Services/Contact alternatives, privacy/legal gate, rail, and complete footer are visible. Geometry height matches this PNG, but CSS width remains 375, so E1 is not resolved.

**Visual convergence: close responsive translation, not certified.** Navy bracketed hero, grey unavailable status, small blue stepped marker, sloping navy/blue seam, large blue calendar-pending module, white angular Services action, underlined Contact status action, and pale legal close agree with the canonical reference. No invented calendar or selectable slots are shown. Omitting the footer booking-status CTA on the booking route is not a defect by itself.

**Visible seam/edge inspection:** header → hero divider clean; hero → calendar sloped join clean; pending text/rule/step motif → alternative links legible; calendar → legal area angled join clean; legal heading → serif content-pending note separated by rule; legal area → walnut rail/footer intact. Top of a supplied crop cuts part of the navigation label, but the full screenshot contains the complete label.

**Unresolved defects:** E1. No additional definite visible layout/seam defect. Calendar and legal publication readiness remain unresolved by design; screenshots do not verify navigation or future integration behavior. No visual PASS or registry promotion is granted.

### 10. `/educational-guide`

**Loaded integrity:** full image and four-section sheet viewed. Resource-unavailable hero, source-status table, no-active-form section, privacy note, rail, and complete footer are visible. E1 remains, despite only a 3px JSON/file height difference.

**Visual convergence: close responsive translation, not certified.** This canonical ref is already a sober status-led layout. Navy hero with bracket, unavailable-resource notice and geometric connector; blue source overview and status table; pale no-requests section with lock card; charcoal privacy note all remain recognizable. No resource download/signup is falsely presented as available.

**Visible seam/edge inspection:** header → hero clean; notice → Services button clean; geometry → blue overview link band clean; link band → source-summary heading has a conspicuous blue pause but no orphaned or missing section; source status table → navy neuropathy panel flush; blue summary → pale no-form area clean; stacked no-form and start-point cards contained; pale → charcoal privacy section clean; privacy card → walnut rail/footer intact.

**Unresolved defects:** E1. No additional definite visible clipping, overlap, failed image load, or seam defect. The blue gap preceding source summary and tall stacked cards increase mobile scroll length, but the supplied desktop ref also budgets generous breathing room; without a mobile ref this is a polish consideration, not a fabricated failure. No visual PASS or registry promotion is granted.

## Findings and exact next ownership

1. **Capture owner:** reconcile E1 on all 10 routes with same-state 390×844 geometry and seam evidence. The current PNGs are real/loaded, but their CSS bounds are not exactly registered to the image state.
2. **Builder:** correct the hormone hero subject framing (V6) and pain/knee stride crop and softness (V4), then provide fresh native mobile image/section comparisons. Preserve approved subject identities and authorized assets.
3. **Builder/design owner:** refine the pelvic hero crop (V8) so the seated person's head/shoulder and intended privacy composition are not unnecessarily cut.
4. **Design owner:** explicitly approve or remediate the revised truthful low-imagery compositions on Services and all five service-detail routes (V1, V3, V5, V7, V9, V10). Approval must cover the replacement visual language, not just correct copy/palette. Unverified reference clinic imagery is not automatically safe to restore.
5. **Content/design owner and builder:** resolve the Services appointment-label/unavailable-state conflict (V2). Screenshot review cannot establish click behavior; visible status-led labeling should agree with the current unavailable-booking state.
6. **Accessibility reviewer:** measure emphasized blue-on-navy text contrast, especially the About hero. This review performed visual inspection, not a formal contrast or assistive-technology audit.

**Registry disposition: remain false.** No PASS is claimed. About, Contact, Book, and Educational Guide are visibly close to their canonical references and have no additional definite seam defect in these images, but the shared evidence-registration issue still blocks certification. The six Services-family routes have additional unresolved composition/fidelity issues, including two clear subject-crop defects. No external system was modified.
