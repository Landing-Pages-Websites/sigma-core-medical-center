# Flow check

Page: `/services/pelvic-floor-incontinence`. Reviewed as one scroll. Route-specific hierarchy retained; no homepage navigation/footer is baked into the contract.

- `01-hero` → `02-private-orientation`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `02-private-orientation` → `03-concerns-and-goals`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `03-concerns-and-goals` → `04-what-to-expect`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `04-what-to-expect` → `05-faq`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `05-faq` → `06-booking-cta`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `06-booking-cta` → `07-medical-sources`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
