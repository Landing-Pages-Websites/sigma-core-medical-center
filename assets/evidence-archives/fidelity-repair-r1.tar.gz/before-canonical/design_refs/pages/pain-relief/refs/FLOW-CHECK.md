# Flow check

Page: `/services/pain-relief`. Reviewed as one scroll. Route-specific hierarchy retained; no homepage navigation/footer is baked into the contract.

- `01-hero` → `02-pain-concern-navigation`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `02-pain-concern-navigation` → `03-knee-concerns`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `03-knee-concerns` → `04-low-back-concerns`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `04-low-back-concerns` → `05-neck-concerns`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `05-neck-concerns` → `06-decision-factors`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `06-decision-factors` → `07-faq`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `07-faq` → `08-booking-cta`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `08-booking-cta` → `09-medical-sources`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
