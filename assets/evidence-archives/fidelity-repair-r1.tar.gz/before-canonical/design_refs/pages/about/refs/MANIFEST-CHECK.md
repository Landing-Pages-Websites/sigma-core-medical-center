# R5 manifest check

Status: CANDIDATE_PENDING_INDEPENDENT_REVIEW. Source copy and actions remain exactly r4 in all six manifest entries. Only Care pixels changed.

| Frame | Evidence |
| --- | --- |
| Hero | Exact r4 bytes and map; movement/function/life, Richmond and neuropathy qualification retained. Electric #0877BE correction retained. |
| Purpose | Exact r4 bytes; neuropathy-first information, complete mission/principles and both actions retained. |
| Location | Exact r4 bytes; unconfirmed visiting/location statement, status qualifications and informational action; zero photos/slots/captions. |
| Care | Full new1536×864 frame inspected: all four exact title/body pairs, both full questions, label and Services-then-Booking actions present. No folios, imagery, navigation or footer. Body ink y391/y387; requested exact alignment/type treatment not fully achieved. |
| Team | Exact r4 bytes; provider publication limits retained; no roster/credentials invented. |
| Booking | Exact r4 bytes; online-only limitation and status action retained. |

All seven informational action occurrences and six anchors plus our-mission remain. No browser navigation or operational readiness is established. Inherited unresolved asset/scanner findings remain open. The native frame is evidence, never a runtime asset.
