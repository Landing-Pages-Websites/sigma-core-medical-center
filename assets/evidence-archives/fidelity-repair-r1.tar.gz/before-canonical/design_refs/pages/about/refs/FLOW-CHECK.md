# R5 flow and boundary evidence

Status: CANDIDATE_PENDING_INDEPENDENT_REVIEW. Producer inspection only; no package approval.

The exact1536×5184 page is the six full native frames concatenated without resampling, overlap or gap. Its overview was inspected; full Care and its numbered overlay were inspected at1536×864. All five after bands were inspected at native1536×512, and changed hard joins3/4 were compared with their native before bands. Before bands come freshly from final r4 owners; after bands come freshly from final r5 owners. Bands are256px from each owner. No new seam repair, patch, relabeling or waiver.

The six distinct silhouettes and quiet Team interval remain. Care retains its charcoal/mineral split and full content. Its upper left title now wraps; body ink alignment improves36px→4px, but exact repair targets remain unmet. The narrower question text reduces some sidebar weight; its final balance still needs independent review. The native bitmap margins do not require fixed-height browser sections. This package has no anchor windows; none were invented or newly generated.

| Seam | Intent | Before/after same pixels | Join mean/max after | Evidence interpretation |
| --- | --- | --- | --- | --- |
| 1 | HARD_TRANSITION | True | 41.205512/107 | Unchanged intentional field break |
| 2 | CONTINUOUS | True | 0.724826/3 | Inherited reviewed pixel continuity, no new repair |
| 3 | HARD_TRANSITION | False | 213.228516/227 | Changed Care edge inspected; intentional clean field break |
| 4 | HARD_TRANSITION | False | 78.183594/239 | Changed Care edge inspected; intentional clean field break |
| 5 | CONTINUOUS | True | 0.782335/4 | Inherited reviewed pixel continuity, no new repair |

Mean/max are absolute RGB row differences at band y255/256, not perceptual thresholds. Continuous seams2/5 exactly equal independently reviewed r3 final evidence; the previous r3 repair metrics are not claimed as new r5 work. All five PASS ledger labels reflect producer seam observation only. Technical continuity, ownership and strict sheet validation exit0; they do not approve Care or the package.
