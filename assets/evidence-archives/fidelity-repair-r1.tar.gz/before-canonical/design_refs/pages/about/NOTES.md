# Candidate decomposition notes

Status: **CANDIDATE_PENDING_INDEPENDENT_REVIEW**. This is material triage, not design approval.

R5 inherits material triage for five byte-identical r4 references. Only Care was newly generated, segmented, visually inspected and measured by the producer. This is not independent decomposition or art approval. Current reference and segmentation hashes are recorded in extraction_plan.json.

All **41 current segmented regions are CODE**, plus six explicitly synthetic ID 0 whole-frame substrate entries. Every current ID and box is copied unchanged. There are zero EXTRACT and zero INPAINT regions. Flat fields, typography, rectangular panels, clipped corners, stair steps, brackets, arrows and short rules all retain their identity with CSS/SVG. Subtle pixel variation in the comps does not justify rasterizing these ordinary surfaces. No evidence contradicts the zero-photo reading.

The six refs and QA PNGs remain evidence only. Every asset_files array is empty. The plan creates no runtime raster, photo slot, photographic caption, or photo-alt assertion. The facility filename describes a location-status design in the pixels, not a gallery. The team frame contains a publication-status message, not provider imagery.

## Shared reconstruction rules

Use Source Sans 3 for all live text roles. Use ink #101E33, mineral #F7F6F3, charcoal #20272E, action #0666A5 and electric #0877BE only where the hero or a local accent requires it. Purpose's upper blue field is action #0666A5, not electric. Its outlined “Explore all services” action has mineral text and border on ink; require at least 4.5:1 text contrast. Text and UI are semantic HTML; decorative paths, brackets and rules are hidden from assistive technology.

Reference coordinates document evidence, not independent absolute-positioned DOM blocks. Fragmented headlines map to one heading; overlapping segmentation crops do not authorize duplicate text. Use grid/flex and shared baselines, font-relative spacing, clamp-based text sizes and responsive padding. Reference sizes in recipes are starting points for visual verification after Source Sans 3 loads. Heights follow content; never set every section to 864px. Preserve deliberate asymmetry while allowing mobile stacking and adequate readable measure.

## Region grouping and overlooked geometry

- Hero IDs 2, 5, 6, 8, 10 compose the single heading “A focus on movement, function and life.” The comma belongs to movement and the terminal period to life. Staircase ID 1 contains incidental neighboring pixels; it owns only the geometric steps. ID 11 owns the mineral rule. ID 0 handles full bleed beyond segmentation's 13px edge inset.
- Purpose ID 1 merges the upper purpose field and mission band. Its recipe retains “Neuropathy first.”, the complete topic paragraph, outcomes caveat, “Our Mission”, the complete mission sentence and both action labels. IDs 3, 5, 4, 2 are the four principles in visible left-to-right order: “You at the center.”, “Questions first.”, “Clear information.”, “Practical next steps.” ID 6 is “Grounded principles”. Thin separators are covered by ID 0.
- Location ID 1 is the chamfered status card, IDs 2 and 3 are its heading group, and ID 4 is “Check location status”. The left bracket, short underline and link arrow are live geometry even where segmentation omits them. Retain the full list of unconfirmed address, hours, directions, parking and accessibility details.
- Care IDs7 and4 form one Care Principles heading. ID3 contains the entire next-step principle; ID2 the entire conversation principle. IDs8/5 pair the expectations heading/body; IDs9/6 pair the outcomes heading/body. ID1 contains the label, both questions and both actions. ID0 owns all omitted rules and the substrate. All copy stays live HTML.
- Team IDs 3, 1 and 2 are the title, publication-status statement and full provider-details caveat. The unsegmented short rule belongs to ID 0. Preserve the asymmetric indentation without making the section a fixed-height empty canvas.
- Booking IDs 5, 6, 7, 4 form one heading “Start with your goals.” ID 3 is its introductory sentence, ID 2 the action, ID 1 the complete status card and ID 8 the independent stepped bracket. Clip geometry never clips live text.

## Observed typography and alignment questions for independent review

The care frame's body text and side-panel labels appear noticeably narrower than the large headline letterforms; pixels alone do not establish a uniform font assignment. Rebuild all roles in the assigned Source Sans 3 and verify weight, measure and line-height together rather than preserving apparent condensed rendering. Purpose's outlined secondary action also has a different apparent label width/weight from the adjacent primary; align both with a shared font, baseline and padding system while preserving their distinct fill treatments.

The purpose principle text starts are not evenly inset from their separators in the reference. Treat the four columns as one grid and review consistent optical padding. In Care, both upper headings now occupy two lines, but their first body ink remains4px apart; use shared heading reserves rather than copying every detected text bbox. The hero h1 has very tight leading and inter-word spacing; verify punctuation clearance and font rendering at desktop and mobile. In booking, the large title and status-card heading approach wide measures; verify wrapping and inner clearance after the font loads.

These are unresolved observations for live typography/alignment review, not instructions to preserve defects. Segmentation overlap, 12–13px border truncation and fragmented word boxes are detection artifacts, not layout design requirements. Parent workflow builds the candidate review sheet; independent art review remains pending.

New Care is a material revision, but exact repair targets remain unmet: first-row body ink y391/y387 (4px stagger, versus r4 36px); requested y382/y382 not reached. Left title wraps after next, rather than one line plus empty second-line reserve. Divider begins y494 (requested y493); blank clearance36/43px exceeds32px. Question typography is modestly lighter/narrower, but sidebar balance and natural uncondensed type require independent judgment. Requested CSS sizes are not proven by generated glyphs.

Care was returned by the sole canonical detached edit and copied without postprocessing. Five other frame bytes remain exactly r4, including its existing seam derivatives. See generation/selected-outputs.json. Hero function/life and steps retain electric #0877BE; action controls and Purpose retain #0666A5.

Before seam bands are freshly extracted from final r4 owners; after bands from final r5 owners. Continuous seams2/5 carry reviewed r3/r4 pixel evidence by equality, with no fictional new repair. Hard seams3/4 were freshly inspected. Exact pixel evidence and technical checks do not approve Care. All requested typography sizes are design targets/initial CSS recipes, not sizes recoverable exactly from bitmap glyphs. R4 completion and cost remain UNKNOWN.
