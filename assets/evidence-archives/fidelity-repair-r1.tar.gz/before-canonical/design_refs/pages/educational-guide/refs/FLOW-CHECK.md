# Guide reference-only flow closure

Independent KEEP: ../evidence/director-fallback-r1-art-review.md. This is canonical reference acceptance only; fresh source-contract verification is next and runtime implementation remains old.

- Q1→Q2, y624: CONTINUOUS #0666a5; fresh evidence seams-after/01-01-resource-hero--02-resource-summary.png.
- Q2→Q3, y1248: HARD_TRANSITION #0666a5→#f7f6f3; fresh evidence seams-after/02-02-resource-summary--03-lead-form.png.
- Q3→Q4, y1797: HARD_TRANSITION #f7f6f3→#20272e; fresh evidence seams-after/03-03-lead-form--04-privacy-note.png.
- Frames1536×624/624/549/512; exact unscaled page.png1536×2309. Bands1536×512 contain last256/first256 owner pixels.
- Amendment ../provenance/fallback-amendment.json: access549=ceil548.625, rail bottom492.625; CSS exit56+entry88=144; native raster144.375 includes0.375 rounding. Supersedes560/504/exact-raster144/stitch2320 only; no source geometry amendment and no143px interval.
- Q4 is byte-preserved KEEP, not recaptured: entry88+complete group224+source exit88+terminal charcoal canvas112=512; terminal rows[400,512) are reference canvas, not runtime padding.
- Hero420×160 open motif terminates inside its owner. No cross-seam motif, neighboring chrome, unintended white separator, clipping or facility imagery in the accepted package.
- Four source sections/five links and unavailable/no-signup/noindex,follow/sitemap exclusion remain. All21 roles are CODE; zero production raster assets.
- SEAM-LEDGER.json retains old before evidence and points to the copied fresh after bands. Structural validator results do not grant aesthetic, runtime or Site Review approval.
- Old page-draft.png and prompts/ are retained history only; no generated r3 imagery obligations are promoted.
