# Guide canonical reference contract

Independent KEEP: ../evidence/director-fallback-r1-art-review.md. Reference-only closure; runtime contract remains old pending separate verification/review.

| Owner | DOM ID | Exact source links |
| --- | --- | --- |
| 01-resource-hero | resource-hero | Explore current services → /services; Read the source overview → #resource-summary |
| 02-resource-summary | resource-summary | Explore neuropathy → /services/neuropathy |
| 03-lead-form | lead-form | Neuropathy → /services/neuropathy |
| 04-privacy-note | privacy-note | See contact status → /contact |

Manifest content equals retained source copy; observations carry matching text/links with zero forms. Resource unavailable/no requests/no signup, robots index:false/follow:true and sitemap_included:false remain exact.
Four owners are CODE with21 measured roles and zero production raster assets. No facility photographs, fake cover, delivery offer or old generated r3 obligations govern this contract.
