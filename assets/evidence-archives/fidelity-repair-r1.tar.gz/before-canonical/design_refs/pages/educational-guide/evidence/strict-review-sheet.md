Reference closure: independent KEEP is recorded in director-fallback-r1-art-review.md; canonical reference-only status is in ../provenance/reference-closure-r1.json.
No new capture or runtime/Site Review claim. The source strict sheet below is preserved verbatim as capture-time evidence; its pending state is historical.

Director fallback r1 strict sheet — worker observation; fresh independent acceptance PENDING.

| Check | Actual evidence / observed state |
| --- | --- |
| Pre-render authority and targets | Amendment+manifest+targets recorded before one render; provenance/pre-render-contract.json hashes |
| Native full viewports/DPR | Fresh1536×624/624/549 at DPR1; Q4 original1536×512 reused, not recaptured |
| Fonts | document.fonts400/600 loaded; CDP custom Source Sans3 and SemiBold; Q4 historical CDP explicitly preserved |
| Minimal paint change | Body owners only: hero/summary #0666a5; access #f7f6f3; privacy #20272e unchanged |
| Source/content fit | Natural heights615.890625/611.65625/548.625/400; all measured geometry/content bounds match old; all text inside owners |
| Hero | Viewed complete; source navy hierarchy/54px Services action/420×160 subordinate motif preserved |
| Summary | Viewed complete; aligned columns/book28/gap32/three rows/adjoining panel preserved |
| Access | Viewed complete; card42/rail separation32/rail bottom492.625/source exit56; no active controls |
| Exact amendment | Native549=ceil548.625; CSS interval144; raster144.375; rounding0.375, not source exit padding |
| Privacy KEEP | Exact original hash;88 entry+224 group+88 source exit+112 terminal canvas; complete Contact action |
| Assembly | Exact unscaled1536×2309; fresh3×1536×512 bands at624/1248/1797; pixel equality proven |
| Visual inspection | All4 owners, all3 bands and whole stitch viewed; white reference-canvas strips absent |
| Continuity | Fresh worker PASS CONTINUOUS/HARD/HARD; official validator exit0; before evidence points to retained original |
| CODE map |21 actual boxes/pixel samples:17 fresh,4 preserved Q4; zero extracted production rasters |
| Copy/links/gate | Fresh HTML equals preserved source serialization; five links retained, zero controls; noindex,follow retained in HTML; runtime not reaudited |
| Frozen scope | Old candidate all bytes unchanged; directly scoped source component/CSS hashes unchanged; no Git/runtime changes |
| Independent acceptance | PENDING fresh controller-arranged review; no inherited art PASS/promotion |
