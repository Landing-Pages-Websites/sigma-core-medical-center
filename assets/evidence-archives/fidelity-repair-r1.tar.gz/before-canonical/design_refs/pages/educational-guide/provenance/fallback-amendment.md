Controller-adopted NON-GENERATIVE fallback under director8d4d0cbd.
{
  "recorded_before_render": true,
  "recorded_at": "2026-10-01T14:00:28.033349+00:00",
  "authority": "director8d4d0cbd-7296-5def-976d-ee300c45c710; controller explicitly adopts concrete fallback",
  "review": "/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a/site_convergence/educational-guide/director-replacement-r1-art-review.md:19-26",
  "scope": "One non-generative fallback; no image API or network except local browser; source geometry/runtime and all visual gates remain frozen. Acceptance pending fresh independent review.",
  "superseded_only": {
    "access_isolated_viewport": 560,
    "access_rail_bottom_exact_raster_target": 504,
    "exact_raster_interval": 144,
    "stitch_height": 2320
  },
  "adopted": {
    "heights": [
      624,
      624,
      549,
      512
    ],
    "stitch": [
      1536,
      2309
    ],
    "joins": [
      624,
      1248,
      1797
    ],
    "access_natural_height_css": 548.625,
    "access_native_height": 549,
    "height_derivation": "ceil(548.625); CODE viewport, no image API multiple-of-16 restriction",
    "observed_access_rail_bottom": 492.625,
    "source_exit_css": 56,
    "privacy_entry_css": 88,
    "natural_css_interval": 144,
    "native_rounding_remainder": 0.375,
    "raster_interval": 144.375,
    "dpr": 1
  },
  "paint_only": {
    "01-resource-hero": "#0666a5",
    "02-resource-summary": "#0666a5",
    "03-lead-form": "#f7f6f3",
    "04-privacy-note": "#20272e unchanged"
  },
  "forbidden": "No content movement, spacers, forced section height, added padding, transforms, owner crop/resize/raster fill, source/runtime changes, generative calls, canonical/registry/implementation contracts/retirement/Git/remotes",
  "q4": "Exact512 native reused byte for byte, not fresh capture; 88+224+88+112 retained"
}
Historical provenance under historical-provenance is superseded only by the explicit amendments above.
