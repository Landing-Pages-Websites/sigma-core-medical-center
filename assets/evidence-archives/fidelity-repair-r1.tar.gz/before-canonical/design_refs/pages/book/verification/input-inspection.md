# Controller input inspection

Status: CANDIDATE_PENDING_INDEPENDENT_REVIEW

Controller inspected original Book frames at native resolution: `01-booking-hero` and `02-gohighlevel-calendar` 1536×864; `03-privacy-note` 1536×512. Original hero contains the misleading booking imperative and an invented branded reception; original calendar includes another unverified premises photo and apparently live booking/policy actions. Original privacy includes unsupported legal/security/emergency copy. They are historical inputs, never a copy or imagery authority for this successor.

Read Book source-truth-r2 independent Art Director review and contract proposal. The review supersedes the proposal's old-H1 preservation request; the current user explicitly resolves that conflict in favor of a status-led H1. Read truthful-metadata-r1-result.md at the current source commit b867d855adb287c71bef1e07487e934edff314c4: all 15 Book fidelity fields remain PENDING, including privacy. A proposal and a readable source capture do not constitute frame approval.

Inspected saved source-truth-r2 desktop 1440×900 and mobile 390×844 section-plus-seam captures for hero, calendar and privacy, plus both desktop and mobile full-page context. Read current hero.tsx, calendar.tsx, privacy.tsx, book.css and app/(batch-three)/book/page.tsx. Current source still has the misleading H1, repeats unavailable status across sections, and retains a redundant future-booking box in privacy. The existing route metadata uses index:false, follow:true. These saved captures are evidence of the earlier reviewed local source, not newly captured candidate implementation.

Read current Services and Contact route owners to verify proposed navigation outcomes. `/services` renders service category information and navigation. `/contact` renders contact/location verification status; its current public address, phone, email and hours are pending. Neither link may be described as sending an appointment request or reaching a verified booking channel.

Design-world check: top-level `design_refs/refs/01-movement-forward.png` is the earlier serif-led territory; the selected Forward Standard anchors are in `design_refs/variation/refs/`. Inspected both hero versions and Direction B `05-what-happens-next`. Existing Book prompts and hard rules explicitly choose Source Sans 3 at display scale, selective Playfair Display, squared brackets, stepped bars and angular apertures. The candidate must name this provenance, inherit approved font families and color tokens, and avoid reinterpreting old source wording as current legal or integration evidence.

Preservation baseline `preservation-before.json` covers 851 files: canonical Book inputs/extractions, homepage identity contracts and stitch, research registry, and every tracked file of the source repository. Pre-existing untracked AGENTS.md and site_convergence/home/narrow-header-r1-art-review.md are recorded in initial Git status and are not task outputs.
