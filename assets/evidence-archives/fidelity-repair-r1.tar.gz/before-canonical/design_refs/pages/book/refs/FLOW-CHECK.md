# Producer native continuity check

**Status: CANDIDATE_PENDING_INDEPENDENT_REVIEW.** Producer and controller continuity observations do not confer the future independent Art Director approval.

Viewed the full native-width 1536×2592 stitch and both full-width 1536×400 seam crops; reopened every final full-resolution frame after cleanup. The story reads navy scheduling status → open blue inactive reserve and useful information routes → quiet mineral legal-content note. There is one booking denial, followed by two different pending facts rather than repeated large denials.

| Seam | Initial finding | Final treatment and observation |
| --- | --- | --- |
| Hero→calendar, y=864 | Small horizontal blue tone break from independent provider generations. | Blank hero bottom and calendar top interpolate to the same exact `#0666A5` row. Core pixels remain raw. Hero diagonal stays at `(0,766)→(631,766)→(1536,627)`, no element clipped. The blue plane carries forward without a new closed panel. |
| Calendar→privacy, y=1728 | Mineral strip was warmer than the following frame, making a faint horizontal band. | Blank calendar mineral handoff and privacy top interpolate to exact `#F7F6F3`. Calendar boundary stays `(0,852)→(478,746)→(1536,746)`. The next title and note sit on the same reading surface. |

The first deterministic full-field color-normalization trial was rejected because preserved old-background fringes created dark outlines around glyphs/bars. Final revision 2 returns to untouched raw provider images and changes only blank seam bands. No foreground glyph, control, keyline or step geometry was modified. `qa/normalize_backgrounds.py`, `qa/background-repair.json` and masks record the final procedure and hashes. `qa/raw-provider/` retains original bytes. Core palette/noise deviations remain documented rather than misrepresented as exact token rendering. Eventual code uses the exact flat palette tokens, with no generated texture, gradients or shadows.

All three section anchors differ: broad kinetic type, open reserve plus narrower navigation, offset quiet note. Heading scale declines through the page. None is a generic centered card stack. No text or foreground motif crosses a seam; each local bracket/rule terminates clearly and only the color plane continues. The privacy bottom stays mineral, with no invented global footer band.

Native frames deliberately share the user-required 1536×864 size. The privacy blank area expresses quiet weighting; it does not impose an 864px minimum height on code. Mobile sequencing and compressed decoration are specified in the map but have not been built or browser-tested. No live painted-edge, source-fidelity, site-wide convergence or publication gate is claimed.

Against selected Direction B native anchors, the candidate retains strong sans scale, squared/angular geometry, stepped signals and a selective serif counterpoint. The absence of photography is an explicit truthful successor override. Canonical A/B provenance tension is recorded in NOTES rather than silently rewritten.
