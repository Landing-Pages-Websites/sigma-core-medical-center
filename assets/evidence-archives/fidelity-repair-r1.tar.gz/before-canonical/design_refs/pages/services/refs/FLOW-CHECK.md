# Flow check

Page: `/services`. Reviewed as one scroll. Route-specific hierarchy retained; no homepage navigation/footer is baked into the contract.

- `01-hero` → `02-neuropathy-feature`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `02-neuropathy-feature` → `03-service-navigation`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `03-service-navigation` → `04-how-to-choose-next-step`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
- `04-how-to-choose-next-step` → `05-booking-cta`: deliberate Direction B hard transition using the manifest background progression; stepped/bracket motifs terminate or re-enter cleanly in code. Core compositions preserved.
