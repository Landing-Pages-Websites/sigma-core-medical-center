NARRATIVE JOB: Convert interest into a booking while exposing the provider-identity review gate.
INTENDED FOCAL POINT: Charcoal next-step section: one quiet reflective lifestyle crop, one concise consultation-literacy panel, and one useful booking action, positioned in the primary visual zone without cropping the complete content group.
INTENDED EYE PATH: headline -> primary action -> authentic image aperture -> lower-edge continuation cue.
TOP EDGE CONTRACT: A clean uninterrupted #20272E field enters from above; any brackets or apertures begin at least 48px below the edge, with no motif crossing the seam. Previous section exits from #F7F6F3.
BOTTOM EDGE CONTRACT: The section resolves to a clean uninterrupted #101E33 edge for the following frame; all bars, brackets, photographs, buttons, and text terminate at least 48px before the seam.

Sigma Core's Forward Standard is a premium contemporary human-performance world built from the real Richmond clinic: electric-blue and warm-mineral fields cut by deep-navy anchors, charcoal architectural voids, cool-silver calibration marks, and restrained walnut evidence from the authentic reception and waiting room. Source Sans 3 becomes the oversized kinetic performance voice while Playfair Display appears only as a selective human counterpoint. Authentic facility photographs behave as panoramic architecture, sharp spatial windows, and tactile material bands, never generic medical stock or small documentary thumbnails. The recurring motif is a disciplined system of stepped signal bars, squared brackets, calibrated rectangular apertures, and angular route modules. Never use decorative numerals, chapter or folio markers, ghost numbers, numeric sequences, 3D sculpture, portals, caves, metallic ribbons, liquid chrome, fantasy architecture, product slabs, material mazes, energy streams, rendered-object typography, medical diagrams, nerves, waveforms, DNA, dashboards, or redesigned logos.

Use case: ui-mockup.
Asset type: 1536x864 straight-on desktop website content-section design reference; edge-to-edge section only, no browser chrome, global navigation, or global footer.
Route identity: A premium personal-goals route expressed with tailored editorial scale, private reflection, and precise goal apertures; never youth restoration, biohacking, medication, laboratory, or body-transformation promises.
Section composition mechanism: Charcoal next-step section: one quiet reflective lifestyle crop, one concise consultation-literacy panel, and one useful booking action.

REAL MANIFEST CONTENT:
- Exact headline: "Responsible Next Step"
- Exact CTA label: "Book an Appointment"; this is a useful route to /book.
- Body-copy direction: State that the responsible prescribing provider, credentials, actual services, and process must be confirmed before clinical copy goes live. Invite booking only after those facts and the calendar are approved.
- Useful manifest-defined routes: /book, /contact
Do not display the instructional phrase “body-copy direction.” Render concise visitor-facing copy that stays strictly within that direction and the approved facts. Major headline and CTA text must be verbatim.

IMAGE ROLE:
Real facility image. Render as a bold Direction B composition; anonymous people are never staff, patients, testimonials, or proof.
When authentic facility context is required, use only the supplied Sigma Core reception or waiting-room reference image and preserve its real architecture and existing logo. Anonymous lifestyle people, if requested, are fully clothed, non-clinical, unlabeled, and never staff, patients, testimonials, or proof.

COMPOSITION AND SEAM BEHAVIOR:
- Native frame 1536x864; keep the complete headline, primary content group, and useful action together with generous safe margins.
- Background entering this frame is #20272E; bottom resolves visually toward #101E33 exactly as contracted.
- Use at least three visible Direction B anchors in this frame: angular aperture, stepped module or signal bars, squared bracket, asymmetric route panel, panoramic architectural band, or dramatic type scale shift.
- Make control-shaped elements only when they have one of these manifest outcomes: /book, /contact.
- Avoid repeating the silhouette of adjacent sections; this frame must express its named route and section job.

TYPOGRAPHY:
Source Sans 3 dominates with large readable performance typography; heavy oversized headlines, 18px-or-larger body intent, and clear action labels. Playfair Display may appear once as a small humane counterpoint, never as the primary system. No decorative numbers or numbered wayfinding.

PALETTE:
Use only deep navy #101E33, electric blue #0877BE, dark electric #0666A5, warm mineral #F7F6F3, charcoal #20272E, cool silver #C7CBD0, restrained walnut #9A572B only through authentic facility/material evidence, white, and approved muted neutrals. Flat fields only: no gradient, glass, chrome, glow, or glossy rendered effects.

COMPLIANCE AND EXCLUSIONS:
- Richmond, Virginia area only. Do not mention Florida or Fort Lauderdale.
- Invent no treatments, protocols, modalities, clinicians, credentials, reviews, testimonials, ratings, statistics, prices, outcomes, phone, email, hours, appointment availability, logistics, or medical claims.
- No youth imagery, before/after, biohacking, pills, syringes, medication, labs, vials, dashboards, or optimization promise.
- Existing Sigma Core logo remains fixed and is never redesigned.
- No 3D/sculptural scene, portal, cave, metallic ribbon, liquid chrome, fantasy architecture, product-render slab, material maze, energy stream, rendered-object typography, decorative numeral, chapter marker, folio, ghost number, or numeric sequence.
- No global navigation or footer.
