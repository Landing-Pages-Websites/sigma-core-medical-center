import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const toolRequire = createRequire(import.meta.url);
const { chromium } = await import(toolRequire.resolve('playwright-core'));
const OUT = path.dirname(fileURLToPath(import.meta.url));
const WIDTHS = [320, 360, 1440];
const SLUGS = ['about', 'book', 'contact', 'educational-guide', 'services',
  'hormone-optimization', 'neuropathy', 'pain-relief', 'pelvic-floor-incontinence', 'regenerative-medicine'];

async function capture(browser, slug, width) {
  const page = await browser.newPage({ viewport: { width, height: 900 }, reducedMotion: 'reduce' });
  try {
    const route = SLUGS.indexOf(slug) > 4 ? `/services/${slug}` : `/${slug}`;
    const response = await page.goto(`http://127.0.0.1:3140${route}`, { waitUntil: 'networkidle', timeout: 15000 });
    const metrics = await page.evaluate(() => ({
      width: innerWidth, scrollWidth: document.documentElement.scrollWidth,
      h1Count: document.querySelectorAll('h1').length,
      sections: Array.from(document.querySelectorAll('main section')).map(node => node.id),
      images: Array.from(document.querySelectorAll('main img')).map(img => ({ alt: img.alt,
        loaded: img.complete && img.naturalWidth > 0, src: img.getAttribute('src') })),
      robots: document.querySelector('meta[name="robots"]')?.getAttribute('content') || null,
    }));
    const filename = `screenshots/${slug}-${width}.png`;
    await page.screenshot({ path: path.join(OUT, filename), fullPage: true });
    return { slug, width, route, status: response.status(), ...metrics, screenshot: filename };
  } catch (error) {
    return { slug, width, error: String(error) };
  } finally {
    await page.close();
  }
}

async function main() {
  let browser;
  const results = [];
  try {
    browser = await chromium.launch({ executablePath: '/var/lib/megaclaw/.cache/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell',
      headless: true, timeout: 8000, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    fs.mkdirSync(path.join(OUT, 'screenshots'), { recursive: true });
    for (const slug of SLUGS) {
      for (const width of WIDTHS) results.push(await capture(browser, slug, width));
      process.stdout.write(`${slug}: captured\n`);
    }
    fs.writeFileSync(path.join(OUT, 'browser.json'), JSON.stringify({ launch: 'PASS', results }, null, 2) + '\n');
  } catch (error) {
    const result = { launch: 'FAIL', limitation: 'browser screenshots unavailable — bootstrap gap', error: String(error) };
    fs.writeFileSync(path.join(OUT, 'browser.json'), JSON.stringify(result, null, 2) + '\n');
    process.stdout.write(result.limitation + '\n');
  } finally {
    if (browser) await browser.close();
  }
}

main().catch(error => { process.stderr.write(`Browser check failed: ${error}\n`); process.exitCode = 1; });
