# Successor integration plan

1. Preserve original uncommitted repair, source audit and research inputs with byte hashes.
2. Integrate the exact authorized descendant chain through 71d5838 by copying only its 74 scoped changed paths. Preserve helpers and existing Book CSS declarations. No homepage or unrelated history.
3. Reconcile runtime inventory against successor and canonical plans. Record contract conflicts without invented approval or asset mappings. Keep legitimate non-use evidence.
4. Run unchanged source audits, scanner regressions, section validators, local build/lint, static 15-route inventory and one browser attempt. Inspect protected-file hashes and final diff.
5. Commit only if all mandatory gates pass; otherwise preserve a precise fail-closed receipt.

Design read: Sigma interior health-information routes guide visitors through category information and honest availability status, retaining the authorized navy/mineral palette, blue wayfinding, bracket geometry and live status compositions. Existing successor components, typography, layout rhythm, responsive behavior and controls are authoritative; this integration does not originate UI or claim fresh visual approval.

Pain Relief is absent from the authorized heads. Canonical About/Book contracts have advanced past this implementation chain; compare their exact claims before reconciling. No external registry, task, review, remote or deployment mutation is authorized.
