# PR40 successor integration — FAIL CLOSED, uncommitted

Candidate branch: `peter/sigma-photo-ownership-round1`. HEAD remains `8c077d6e5aeacdab4b5b61d97987c8c05dc40d7a`. Supplied PR40 head: `452fa6f11a2ac76cb1afaed33336e24c7fe1c396`. **No new commit SHA. No push, merge, deploy, registry, task or Site Review action.** The mandatory source gate did not pass, so no commit was created.

The original `pr40-source-contract-audit/` README was read first. Its complete reports, original uncommitted helpers/manifest/plans and ignored AGENTS.md were preserved before editing. Original audit receipt SHA-256: `f53f91235643702a6a3fb0ac74438c2864b030102dbd8a69afeeea6f23877d77`. Every original audit file and AGENTS.md is still byte-identical; see initial-state.json and integrity.json. Historical executable-source snapshots have a `.snapshot` suffix to keep evidence distinct from active scanner input; no photo was transformed for scanning.

The six supplied successor heads form one 31-commit descendant chain through `71d5838a207cdcf9f24b98af3daa66ff7470ad71`. Equivalent content-preserving integration copied exactly its 74 scoped changed blobs: 64 application/component files, six section implementation files and four successor plan/NOTES files. Runtime code remains byte-identical to the authorized successor heads; the 20 route plans/NOTES were then reconciled as audit contracts. See integration-plan.json, integration-receipt.json and authorized-commit-chain.txt. No unrelated branch history was imported. Pain Relief has no authorized successor in the supplied list and its runtime is unchanged.

The prior two helper changes remain behaviorally identical and necessary for scanner-visible literal URLs: 20 exact runtime mappings, exact source-component and section owners, 40 matching before/after helper renders, and fail-closed unknown-asset lookup. The manifest records use, not source approval. Dynamic URLs, alt text, fill, sizes, classes, priority and image geometry are unchanged.

All ten in-repo extraction plans and NOTES describe current runtime ownership, narrative jobs, source provenance and unresolved differences. `asset_file` exists only for the nine genuine runtime rasters supported by selected contracts; eleven further runtime rasters are explicit unresolved records, never fake approved mappings. CODE regions have lowercase `verdict: code` and no asset_file. Current canonical About/Book/Contact/Guide references are newer or separately reviewed and are preserved without transferring their review claims. Only the stale Pelvic extraction plan and NOTES were mirrored to research, using the exact `0780261` committed successor bytes. Both previous canonical files and the replacements are preserved with hashes in research-mirror.json; the change is reversible.

Forty-two rasters removed from use by these exact successors were first recorded as non-use, then reversibly retired to `assets/retired-photo-roles/pr40-successor/<slug>/<original-basename>`. Every byte and basename is preserved. Before/after whole-source scanner reports prove that retirement changed neither production image references nor perceptual duplicate inputs/findings. This is retirement of unsupported, unreferenced shipped payloads, not a duplicate bypass. Active About, Contact and Pain Relief photographs remain at their original URLs. See retirement-receipt.json and retirement-verification.json.

## Current unbypassed audit

`python3 site_convergence/pr40-successor-audit/run_audit.py` invokes the unchanged installed `audit_design_handoff.py` ten times with the current research section manifest/composition map, current in-repo extraction plan, complete current route asset directory and this checkout as `--source-root`, plus `--check`. **No allow flags, scanner patch or edge flags.** Each full argv, shell command, command/input/report SHA-256, exit code and source/asset hashes is recorded in audit-run.json; complete JSON and stderr/stdout logs are under reports/. Historical intermediate runs remain under first-audit/ and pre-retirement-audit/.

| Route | Frames | Mapping | Sources | Role reuse | Duplicate content | Section validator |
| --- | --- | --- | --- | --- | --- | --- |
| about | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| book | PASS | PASS | PASS | PASS | FAIL | PASS (structure only) |
| contact | PASS | FAIL | PASS | PASS | FAIL | FAIL — review pending |
| educational-guide | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| hormone-optimization | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| neuropathy | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| pain-relief | PASS | FAIL | PASS | PASS | FAIL | FAIL — review pending |
| pelvic-floor-incontinence | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| regenerative-medicine | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |
| services | PASS | PASS | PASS | PASS | FAIL | FAIL — review pending |

All ten route audits exit 1. Frame contracts, source references and asset-role reuse pass on all ten. Asset mapping passes on eight routes; Contact has one unmapped live raster and Pain Relief has ten. Duplicate content fails on every route because the installed scanner checks the whole source tree.

The sole remaining duplicate pair is `images/design/about/03-facility-gallery-01-real-reception.png` and `images/shared/reception-2.png`, perceptual distance 0. The first is the authorized About gallery's client-supplied reception, resolved through the literal runtime manifest. The shared copy has two protected source occurrences in `src/components/variant-a/place-of-care.tsx:35` and `:46`; `/variant-a` itself returns notFound. There is no new same-page runtime repetition. The corrected About successor reuse disclosure names both owners/jobs and does not claim approval for a live cross-route recurrence. Canonical About r5 is all-CODE, so inserting a fake reuse authorization into that newer canonical plan would be dishonest. Installed scanning does not account for route reachability or consume this disclosure. No CLI exemption was used.

## Verification and limits

- Final `npm run build`, `npm run lint`, and `git diff --check`: PASS with real local dependencies. No tracked dependency files or symlinks. Commands, exit codes and log hashes are retained.
- All 13 installed source-audit regression tests PASS. All five installed section-validator regression tests PASS. Installed scanner/schema/regression bytes match the preserved prior receipt.
- Runtime asset helper: all 20 URLs and owners verified; 40 direct before/after renders identical. Plan structure/ownership consistency PASS on all ten; this is not approval of the eleven unresolved photos.
- All 15 approved review routes remain declared. HTML/a11y checks PASS for one H1, image existence/alt presence, unique IDs, no raw submit buttons and no empty navigation controls. Book, Guide and all four legal/accessibility utilities remain gated, without forms, and `noindex, follow`.
- Homepage, both variant pages and all four utility-page DOM/text/image/robots output match the preserved baseline. No homepage, variant, global stylesheet, package or registry/task files were changed. Every original Book CSS line remains present, including the existing repair; added Book CSS is exact authorized successor content.
- Section JSON validation is shown above. Nine routes retain pending review statuses and fail the unchanged validator. Book passes its shape/status check but has inherited stale “undefined” fidelity evidence and photo-composition claims. No fidelity status was flipped to PASS and no new visual approval is claimed.
- **browser screenshots unavailable — bootstrap gap**: one 8-second-limit launch failed immediately on missing `libnspr4.so`. No browser/system dependency install or retry occurred. DOM checks cannot establish 320px/360px painted layout, cropping, overflow, focus visibility or visual fidelity.
- Contact remains indexable in the exact authorized foundation, as in the original candidate. Its newer source NOTES' noindex claim is not proof of runtime metadata. Exact metadata was preserved rather than inventing an unlisted successor decision.
- `simplify` is unavailable (exit 127); no corresponding skill was found. Manual source review is recorded in code-review.md. No commit gate was bypassed.

## Exact next owners/actions

1. **Integration controller / Pain Relief owner:** supply the exact authorized Pain Relief successor commit. Current canonical CODE contracts conflict with ten still-rendered photos. No extra local branch was guessed or integrated.
2. **Contact successor owner / integration controller:** supply an authorized source-backed replacement for `src/components/batch-three/contact/booking.tsx` and `04-booking-cta-01-clinic-reception.png`. The listed foundation changes the facility section but retains this rejected booking photograph.
3. **Source-contract/scanner owner, with the integration controller:** resolve the About reception vs dormant Variant A source occurrence. Under the present boundary, the homepage variants are protected. An approved scanner revision must represent actual production reachability or specifically reviewed photo-use contracts without CLI exemptions; alternatively the controller must authorize a separate exact successor that resolves the conflicting source occurrence. This task did neither. The newer all-CODE About r5 contract must not be relabeled as approving the older photo.
4. **Independent design/source reviewer:** reconcile newer About, Book, Contact and Guide reference contracts with the selected authorized implementation scope, replace stale Book fidelity evidence, and complete the pending section reviews after the source/runtime blockers are resolved. The environment owner must provide a functioning browser bootstrap for painted review.

Re-run all current-tree gates after those decisions. Commit only after every one of the ten unbypassed five-check audits and build/lint passes; use a successor source-contract integration message. This candidate remains local and uncommitted.

## Exact changed paths

`changed-paths.txt` lists every application, contract and retirement path changed relative to HEAD, including prior uncommitted files. `changed-paths.json` additionally enumerates all prior/new audit evidence and deleted public paths. The ignored root AGENTS.md and successor worktrees' AGENTS.md files are not staged or committed. `SHA256SUMS.json` records final evidence/artifact hashes. No index entries were staged.

- `app/(batch-three)/about/about.css`
- `app/(batch-three)/about/page.tsx`
- `app/(batch-three)/batch-three.css`
- `app/(batch-three)/book/page.tsx`
- `app/(batch-three)/contact/page.tsx`
- `app/(batch-three)/educational-guide/guide.css`
- `app/(batch-three)/educational-guide/page.tsx`
- `app/services/hormone-optimization/page.css`
- `app/services/neuropathy/neuropathy.css`
- `app/services/neuropathy/page.tsx`
- `app/services/page.tsx`
- `app/services/pelvic-floor-incontinence/page.css`
- `app/services/pelvic-floor-incontinence/page.tsx`
- `app/services/regenerative-medicine/page.css`
- `app/services/source-truth.css`
- `assets/retired-photo-roles/pr40-successor/README.md`
- `assets/retired-photo-roles/pr40-successor/about/03-facility-gallery-02-client-waiting-room.png`
- `assets/retired-photo-roles/pr40-successor/about/04-care-principles-01-clinic-signage.png`
- `assets/retired-photo-roles/pr40-successor/about/04-care-principles-02-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/about/05-team-publication-gate-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/about/06-booking-cta-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/book/01-booking-hero-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/book/02-gohighlevel-calendar-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/contact/03-facility-image-01-real-waiting-room.png`
- `assets/retired-photo-roles/pr40-successor/educational-guide/01-resource-hero-01-clinic-interior.png`
- `assets/retired-photo-roles/pr40-successor/educational-guide/02-resource-summary-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/educational-guide/03-lead-form-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/educational-guide/04-privacy-note-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/02-visitor-orientation-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/03-goals-and-decision-factors-01-clinic-interior-strip.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/04-responsible-next-step-01-visitor-in-clinic.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/05-faq-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/06-booking-cta-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/hormone-optimization/07-medical-sources-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/02-visitor-orientation-01-clinic-interior.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/03-goals-and-decision-factors-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/03-goals-and-decision-factors-02-visitor-in-lounge.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/05-faq-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/06-booking-cta-01-visitor-in-clinic.png`
- `assets/retired-photo-roles/pr40-successor/neuropathy/07-medical-sources-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/02-private-orientation-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/03-concerns-and-goals-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/05-faq-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/06-booking-cta-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/06-booking-cta-02-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/pelvic-floor-incontinence/07-medical-sources-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/01-hero-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/03-questions-for-a-consultation-01-clinic-interior-strip.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/04-decision-factors-01-clinic-left.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/04-decision-factors-02-clinic-right.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/05-faq-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/06-booking-cta-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/regenerative-medicine/07-medical-sources-01-clinic-lounge.png`
- `assets/retired-photo-roles/pr40-successor/services/01-hero-01-reception.png`
- `assets/retired-photo-roles/pr40-successor/services/02-neuropathy-feature-02-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/services/03-service-navigation-02-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/services/04-how-to-choose-next-step-01-clinic-reception.png`
- `assets/retired-photo-roles/pr40-successor/services/05-booking-cta-01-clinic-reception.png`
- `public/design/pages/about/section_implementation.json`
- `public/design/pages/educational-guide/section_implementation.json`
- `public/design/pages/hormone-optimization/section_implementation.json`
- `public/design/pages/pelvic-floor-incontinence/section_implementation.json`
- `public/design/pages/regenerative-medicine/section_implementation.json`
- `public/design/pages/services/section_implementation.json`
- `public/images/design/about/03-facility-gallery-02-client-waiting-room.png`
- `public/images/design/about/04-care-principles-01-clinic-signage.png`
- `public/images/design/about/04-care-principles-02-clinic-lounge.png`
- `public/images/design/about/05-team-publication-gate-01-clinic-reception.png`
- `public/images/design/about/06-booking-cta-01-clinic-reception.png`
- `public/images/design/about/NOTES.md`
- `public/images/design/about/extraction_plan.json`
- `public/images/design/book/01-booking-hero-01-clinic-reception.png`
- `public/images/design/book/02-gohighlevel-calendar-01-clinic-lounge.png`
- `public/images/design/book/NOTES.md`
- `public/images/design/book/extraction_plan.json`
- `public/images/design/contact/03-facility-image-01-real-waiting-room.png`
- `public/images/design/contact/NOTES.md`
- `public/images/design/contact/extraction_plan.json`
- `public/images/design/educational-guide/01-resource-hero-01-clinic-interior.png`
- `public/images/design/educational-guide/02-resource-summary-01-clinic-reception.png`
- `public/images/design/educational-guide/03-lead-form-01-clinic-lounge.png`
- `public/images/design/educational-guide/04-privacy-note-01-clinic-reception.png`
- `public/images/design/educational-guide/NOTES.md`
- `public/images/design/educational-guide/extraction_plan.json`
- `public/images/design/hormone-optimization/02-visitor-orientation-01-clinic-reception.png`
- `public/images/design/hormone-optimization/03-goals-and-decision-factors-01-clinic-interior-strip.png`
- `public/images/design/hormone-optimization/04-responsible-next-step-01-visitor-in-clinic.png`
- `public/images/design/hormone-optimization/05-faq-01-clinic-lounge.png`
- `public/images/design/hormone-optimization/06-booking-cta-01-clinic-reception.png`
- `public/images/design/hormone-optimization/07-medical-sources-01-clinic-reception.png`
- `public/images/design/hormone-optimization/NOTES.md`
- `public/images/design/hormone-optimization/extraction_plan.json`
- `public/images/design/neuropathy/02-visitor-orientation-01-clinic-interior.png`
- `public/images/design/neuropathy/03-goals-and-decision-factors-01-clinic-reception.png`
- `public/images/design/neuropathy/03-goals-and-decision-factors-02-visitor-in-lounge.png`
- `public/images/design/neuropathy/05-faq-01-clinic-lounge.png`
- `public/images/design/neuropathy/06-booking-cta-01-visitor-in-clinic.png`
- `public/images/design/neuropathy/07-medical-sources-01-clinic-lounge.png`
- `public/images/design/neuropathy/NOTES.md`
- `public/images/design/neuropathy/extraction_plan.json`
- `public/images/design/pain-relief/NOTES.md`
- `public/images/design/pain-relief/extraction_plan.json`
- `public/images/design/pelvic-floor-incontinence/02-private-orientation-01-clinic-lounge.png`
- `public/images/design/pelvic-floor-incontinence/03-concerns-and-goals-01-clinic-reception.png`
- `public/images/design/pelvic-floor-incontinence/05-faq-01-clinic-lounge.png`
- `public/images/design/pelvic-floor-incontinence/06-booking-cta-01-clinic-reception.png`
- `public/images/design/pelvic-floor-incontinence/06-booking-cta-02-clinic-lounge.png`
- `public/images/design/pelvic-floor-incontinence/07-medical-sources-01-clinic-lounge.png`
- `public/images/design/pelvic-floor-incontinence/NOTES.md`
- `public/images/design/pelvic-floor-incontinence/extraction_plan.json`
- `public/images/design/regenerative-medicine/01-hero-01-clinic-reception.png`
- `public/images/design/regenerative-medicine/03-questions-for-a-consultation-01-clinic-interior-strip.png`
- `public/images/design/regenerative-medicine/04-decision-factors-01-clinic-left.png`
- `public/images/design/regenerative-medicine/04-decision-factors-02-clinic-right.png`
- `public/images/design/regenerative-medicine/05-faq-01-clinic-reception.png`
- `public/images/design/regenerative-medicine/06-booking-cta-01-clinic-reception.png`
- `public/images/design/regenerative-medicine/07-medical-sources-01-clinic-lounge.png`
- `public/images/design/regenerative-medicine/NOTES.md`
- `public/images/design/regenerative-medicine/extraction_plan.json`
- `public/images/design/services/01-hero-01-reception.png`
- `public/images/design/services/02-neuropathy-feature-02-clinic-reception.png`
- `public/images/design/services/03-service-navigation-02-clinic-reception.png`
- `public/images/design/services/04-how-to-choose-next-step-01-clinic-reception.png`
- `public/images/design/services/05-booking-cta-01-clinic-reception.png`
- `public/images/design/services/NOTES.md`
- `public/images/design/services/extraction_plan.json`
- `src/components/batch-three/about/booking.tsx`
- `src/components/batch-three/about/gallery-status-rail.tsx`
- `src/components/batch-three/about/gallery.tsx`
- `src/components/batch-three/about/principles.tsx`
- `src/components/batch-three/about/team.tsx`
- `src/components/batch-three/book/book.css`
- `src/components/batch-three/book/calendar.tsx`
- `src/components/batch-three/book/hero.tsx`
- `src/components/batch-three/contact/facility-area.tsx`
- `src/components/batch-three/contact/facility-status.tsx`
- `src/components/batch-three/contact/facility.css`
- `src/components/batch-three/contact/facility.tsx`
- `src/components/batch-three/design-photo.tsx`
- `src/components/batch-three/educational-guide/availability.tsx`
- `src/components/batch-three/educational-guide/hero.tsx`
- `src/components/batch-three/educational-guide/privacy.tsx`
- `src/components/batch-three/educational-guide/summary.tsx`
- `src/components/interior/batch-booking.tsx`
- `src/components/interior/hormone-optimization/booking.tsx`
- `src/components/interior/hormone-optimization/faq.tsx`
- `src/components/interior/hormone-optimization/goals.tsx`
- `src/components/interior/hormone-optimization/hero.tsx`
- `src/components/interior/hormone-optimization/next-step.tsx`
- `src/components/interior/hormone-optimization/orientation.tsx`
- `src/components/interior/hormone-optimization/sources.tsx`
- `src/components/interior/interior-image.tsx`
- `src/components/interior/neuropathy/booking.tsx`
- `src/components/interior/neuropathy/expect.tsx`
- `src/components/interior/neuropathy/faq.tsx`
- `src/components/interior/neuropathy/goals.tsx`
- `src/components/interior/neuropathy/hero.tsx`
- `src/components/interior/neuropathy/orientation.tsx`
- `src/components/interior/neuropathy/sources.tsx`
- `src/components/interior/pelvic-floor-incontinence/booking.tsx`
- `src/components/interior/pelvic-floor-incontinence/expect.tsx`
- `src/components/interior/pelvic-floor-incontinence/faq.tsx`
- `src/components/interior/pelvic-floor-incontinence/goals.tsx`
- `src/components/interior/pelvic-floor-incontinence/hero.tsx`
- `src/components/interior/pelvic-floor-incontinence/orientation.tsx`
- `src/components/interior/pelvic-floor-incontinence/sources.tsx`
- `src/components/interior/regenerative-medicine/booking.tsx`
- `src/components/interior/regenerative-medicine/decisions.tsx`
- `src/components/interior/regenerative-medicine/faq.tsx`
- `src/components/interior/regenerative-medicine/hero.tsx`
- `src/components/interior/regenerative-medicine/questions.tsx`
- `src/components/interior/regenerative-medicine/sources.tsx`
- `src/components/interior/services/booking.tsx`
- `src/components/interior/services/choose.tsx`
- `src/components/interior/services/hero.tsx`
- `src/components/interior/services/navigation.tsx`
- `src/components/interior/services/neuropathy.tsx`
- `src/content/design-assets.ts`
