"""Describe the authorized runtime without manufacturing raster approvals."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RESEARCH = Path('/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a')
USES = json.loads((OUT / 'runtime-uses.json').read_text())
NON_USE = json.loads((OUT / 'successor-non-use.json').read_text())
COMMITS = {'about': '6c98505', 'book': '6c98505', 'contact': '6c98505',
           'educational-guide': '6c98505', 'services': 'afb37ce', 'neuropathy': '71d5838',
           'hormone-optimization': 'bec8b99', 'pelvic-floor-incontinence': '0780261',
           'regenerative-medicine': 'ac9296b', 'pain-relief': '8c077d6'}
CONFLICTS = {
    'about': 'Canonical About r5 is a newer all-CODE candidate. The explicitly authorized 6c98505 successor retains one client reception photograph. Its branch plan governs this integration; canonical r5 is preserved, not downgraded or relabeled stale.',
    'book': 'Canonical Book describes a later reviewed successor, not the authorized 4ff1fff/6c98505 runtime. Both are all-CODE; its KEEP and exact composition claims do not transfer to this candidate.',
    'contact': 'Canonical Contact is a newer zero-raster candidate. The authorized foundation changes the facility section but still renders the older booking-room raster. No replacement for that booking component is in the authorized chain.',
    'educational-guide': 'Canonical Guide reference-only KEEP is not a live approval of this authorized 6c98505 implementation. Both use CODE; source-reference measurements are retained as reference evidence only.',
    'pain-relief': 'No Pain Relief successor commit was authorized in the supplied list. Ten current runtime rasters conflict with canonical CODE regions. No fabricated mappings are added.'}
JOBS = {
    'about': ['Introduce Sigma Core and the scope of its care information.', 'Explain the clinic purpose and route visitors to service information.', 'Identify one supplied reception view while withholding address and visit verification.', 'Explain care principles with live editorial text.', 'State that team details remain unpublished until verified.', 'Explain unavailable scheduling and direct visitors to its status.'],
    'book': ['Explain online scheduling is unavailable without accepting appointment requests.', 'Show an inactive calendar and explain the next available information paths.', 'State privacy and emergency boundaries without collecting data.'],
    'contact': ['Orient visitors to Richmond-area contact information pending verification.', 'Withhold unverified address and public contact details.', 'Explain the unverified visit status using live text and code-native geometry.', 'Explain unavailable appointment scheduling; legacy reception raster remains an unresolved contract conflict.'],
    'educational-guide': ['State that the educational resource is unavailable and link to services.', 'Explain what source information exists without offering an unapproved download.', 'Keep resource delivery gated; no form, video or download is offered.', 'Explain privacy and contact boundaries without collecting information.'],
    'services': ['Introduce the service categories through code-native wayfinding.', 'Orient visitors to neuropathy information with the approved small walking inset.', 'Compare service categories with one approved active-couple panel for pain relief.', 'Help visitors choose a next information step using live decision text.', 'Explain booking status and provide useful lower route links.']}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def read_contract(slug):
    relative = f'public/images/design/{slug}/extraction_plan.json'
    canonical = OUT / 'research-inputs/design_assets/pages' / slug / 'extraction_plan.json'
    if slug not in ('about', 'pelvic-floor-incontinence'):
        return json.loads(canonical.read_text()), str(canonical.relative_to(ROOT)), sha(canonical)
    data = subprocess.check_output(['git', 'show', f'{COMMITS[slug]}:{relative}'], cwd=ROOT)
    target = OUT / 'successor-inputs' / slug / 'extraction_plan.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    notes = subprocess.check_output(['git', 'show', f'{COMMITS[slug]}:public/images/design/{slug}/NOTES.md'], cwd=ROOT)
    target.with_name('NOTES.md').write_bytes(notes)
    return json.loads(data), f'git:{COMMITS[slug]}:{relative}', hashlib.sha256(data).hexdigest()


def narrative(slug, frame, index):
    if slug in JOBS:
        return JOBS[slug][index]
    subject = slug.replace('-', ' ')
    role = frame.split('-', 1)[1].replace('-', ' ')
    jobs = [('hero', f'Introduce {subject} information and its limits.'),
            ('source', f'Name the evidence and review boundaries for {subject}.'),
            ('booking', f'Explain scheduling status and next questions about {subject}.'),
            ('faq', f'Answer common {subject} questions without diagnosing or promising outcomes.'),
            ('orientation', f'Orient visitors to the scope and limits of {subject} information.'),
            ('goals', f'Help visitors identify personal goals and questions about {subject}.'),
            ('expect', f'Explain preparation and verification boundaries for a {subject} conversation.')]
    return next((job for key, job in jobs if key in role), f'Explain {role} as a specific part of the {subject} decision, preserving source-backed copy.')


def use_record(use):
    public = ROOT / 'public' / use['src'].lstrip('/')
    archive = ROOT / 'assets/retired-photo-roles/pr40-successor' / use['key']
    return {**use, 'sha256': sha(public if public.exists() else archive)}


def non_use_record(use, slug):
    records = json.loads((OUT / 'retirement-receipt.json').read_text()) if (OUT / 'retirement-receipt.json').exists() else []
    retired = next((r for r in records if r['key'] == use['key']), None)
    record = {**use_record(use), 'successor_commit': COMMITS[slug],
        'reason': 'Exact authorized successor removed this runtime use and replaced the section with live code.'}
    if retired:
        record.update({'archive_path': retired['archive_path'], 'previous_public_path': retired['previous_path'], 'reason': retired['reason']})
    return record


def annotate_region(region, owner, component, job):
    region['verdict'] = str(region.get('verdict') or region.get('decision') or 'code').lower()
    region['section_owner'] = owner
    region['source_component'] = component
    region['narrative_job'] = region.get('narrative_job') or job
    if region['verdict'] == 'code':
        assert not region.get('asset_file'), region
    if region.get('asset_file') == '03-facility-gallery-01-real-reception.png':
        region['reuse_intent'] = ('About gallery.tsx / 03-facility-gallery identifies the supplied reception with an explicit location caveat. '
            'src/components/variant-a/place-of-care.tsx / place-of-care references the identical shared reception-2 photograph as historical premises context, '
            'but /variant-a returns notFound. This is a disclosed dormant source occurrence, not an approved live cross-route recurrence or scanner exemption. '
            'Contact successor facility contains no photograph; the earlier Contact-reuse statement is superseded.')
        region['source_sha256'] = sha(ROOT / 'public/images/design/about' / region['asset_file'])


def reconcile_frame(slug, frame, section, index):
    owner = frame['frame'].removesuffix('.png')
    component = section['implementation_owner']
    job = narrative(slug, owner, index)
    source = (ROOT / component).read_text()
    uses = [use_record(u) for u in USES if u['key'].startswith(slug + '/') and u['sectionOwner'] == owner]
    for region in frame['regions']:
        annotate_region(region, owner, component, job)
    mapped = {r['asset_file'] for r in frame['regions'] if r.get('asset_file')}
    assert mapped <= {Path(u['key']).name for u in uses}, (slug, owner, mapped)
    rejected = [u for u in uses if Path(u['key']).name not in mapped]
    frame['expected_asset_count'] = len(mapped)
    frame['runtime_contract'] = {'source_component': component, 'source_sha256': sha(ROOT / component),
        'section_owner': owner, 'narrative_job': job, 'dom_ids': re.findall(r'\bid="([^"]+)"', source),
        'implementation': 'mixed live HTML and raster' if uses else 'code-native live HTML/CSS/SVG',
        'runtime_uses': uses, 'unresolved_runtime_rasters': rejected,
        'note': 'Region geometry/recipes above describe the cited source contract. This hashed owner describes actual runtime; reference review does not certify runtime fidelity.'}
    return rejected


def reconcile_route(slug):
    plan, source, source_hash = read_contract(slug)
    metadata = {k: v for k, v in plan.items() if k != 'frames'}
    sections = json.loads((ROOT / f'public/design/pages/{slug}/section_implementation.json').read_text())['sections']
    owners = {s['frame'].removesuffix('.png'): s for s in sections}
    rejected = [u for i, f in enumerate(plan['frames']) for u in reconcile_frame(slug, f, owners[f['frame'].removesuffix('.png')], i)]
    non_use = [non_use_record(u, slug) for u in NON_USE if u['key'].startswith(slug + '/')]
    contract = {'status': 'UNCOMMITTED_NOT_APPROVED', 'implementation_commit': COMMITS[slug],
        'input_contract': source, 'input_sha256': source_hash, 'source_reference_metadata': metadata,
        'canonical_comparison': CONFLICTS.get(slug, 'Raster roles match the explicitly authorized source-truth successor.'),
        'unresolved_runtime_rasters': rejected, 'explicit_non_use': non_use,
        'audit_boundary': 'Unchanged installed scanner, entire current public route directory and current source root, no allow flags. Unreferenced successor retirements are preserved byte-for-byte outside public; active comparison inputs are unchanged.'}
    result = {'page': slug, 'status': 'UNCOMMITTED_NOT_APPROVED', 'frames': plan['frames'], 'successor_source_contract': contract}
    destination = ROOT / 'public/images/design' / slug
    write_json(destination / 'extraction_plan.json', result)
    write_notes(destination / 'NOTES.md', slug, result)
    return {'slug': slug, **contract, 'mapped_raster_count': sum(f['expected_asset_count'] for f in plan['frames'])}


def write_notes(path, slug, plan):
    contract = plan['successor_source_contract']
    lines = [f'# {slug} — authorized successor runtime reconciliation', '',
             f'Implementation source: `{COMMITS[slug]}`. Status: **uncommitted, not approved**.', '',
             contract['canonical_comparison'], '',
             f"Contract source: `{contract['input_contract']}`; SHA-256 `{contract['input_sha256']}`.", '',
             'Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.', '']
    for frame in plan['frames']:
        runtime = frame['runtime_contract']
        lines.extend([f"## {runtime['section_owner']}", '', runtime['narrative_job'], '',
            f"Owner: `{runtime['source_component']}`. Actual treatment: {runtime['implementation']}.",
            f"Mapped rasters: {frame['expected_asset_count']}; runtime rasters: {len(runtime['runtime_uses'])}.", ''])
        lines += [f"- UNRESOLVED runtime: `{u['key']}`. Canonical CODE contract supplies no approval; no asset_file mapping invented." for u in runtime['unresolved_runtime_rasters']]
        lines += [f"- Reuse disclosure: {r['reuse_intent']}" for r in frame['regions'] if r.get('reuse_intent')]
    lines += ['', '## Preserved non-use evidence', '', 'The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.', '']
    lines += [f"- `{u['key']}`: former owner `{u['sourceComponent']}`, superseded by `{u['successor_commit']}`; SHA-256 `{u['sha256']}`." for u in contract['explicit_non_use']]
    lines += ['', 'No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.', '']
    path.write_text('\n'.join(lines))


if __name__ == '__main__':
    records = [reconcile_route(slug) for slug in sorted(COMMITS)]
    write_json(OUT / 'reconciliation.json', records)
    print([(r['slug'], r['mapped_raster_count'], len(r['unresolved_runtime_rasters']), len(r['explicit_non_use'])) for r in records])
