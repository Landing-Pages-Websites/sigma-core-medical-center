"""Capture exact local gate commands, exit codes, elapsed times and log hashes."""
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SCRIPTS = Path('/var/lib/megaclaw/workspace/skills/website-orchestrator/scripts')
RESEARCH = Path('/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, args, timeout=180):
    started = time.monotonic()
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    log = OUT / f'{name}.log'
    try:
        with log.open('w') as output:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
        code = result.returncode
    except (OSError, subprocess.TimeoutExpired) as error:
        with log.open('a') as output:
            output.write(f'\nGate execution failed: {error}\n')
        code = 124
    command = shlex.join(args)
    record = {'command': command, 'argv': args, 'command_sha256': hashlib.sha256(command.encode()).hexdigest(),
        'exit_code': code, 'elapsed_seconds': round(time.monotonic() - started, 2), 'log': str(log.relative_to(ROOT)), 'log_sha256': sha(log)}
    (OUT / f'{name}-command.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name, 'PASS' if code == 0 else 'FAIL', code, flush=True)
    return record


def sections():
    records = []
    for path in sorted((ROOT / 'public/design/pages').glob('*/section_implementation.json')):
        slug = path.parent.name
        args = [sys.executable, str(SCRIPTS / 'validate_section_implementation.py'), '--file', str(path),
            '--manifest', str(RESEARCH / 'design_refs/pages' / slug / 'section_manifest.json'), '--source-root', str(ROOT), '--check']
        record = run(f'section-{slug}', args)
        record['slug'] = slug
        record['input_sha256'] = {str(p): sha(p) for p in [path, Path(args[5]), SCRIPTS / 'validate_section_implementation.py']}
        records.append(record)
    (OUT / 'section-validation.json').write_text(json.dumps(records, indent=2) + '\n')


if __name__ == '__main__':
    group = sys.argv[1]
    if group == 'build':
        run('build', ['npm', 'run', 'build'], 240)
    elif group == 'lint':
        run('lint', ['npm', 'run', 'lint'])
    elif group == 'audit':
        run('source-audit', [sys.executable, str(OUT / 'run_audit.py')], 240)
    elif group == 'tests':
        run('diff-check', ['git', 'diff', '--check'])
        run('scanner-regressions', [sys.executable, str(OUT / 'test_audit.py')])
        run('runtime-tests', ['node', str(OUT / 'test_runtime.mjs')])
        sections()
