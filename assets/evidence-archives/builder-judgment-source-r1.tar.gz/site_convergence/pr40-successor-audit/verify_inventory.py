"""Verify declared routes, rendered HTML, protected scope and unchanged evidence."""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / 'site_convergence/pr40-source-contract-audit'
SPEC = importlib.util.spec_from_file_location('prior_capture', PRIOR / 'capture_html.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
INITIAL = json.loads((OUT / 'initial-state.json').read_text())
DESIGNED = sorted(p.parent.name for p in (ROOT / 'public/images/design').glob('*/extraction_plan.json'))
UTILITIES = ['accessibility', 'notice-of-privacy-practices', 'privacy', 'terms']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def route_for(slug):
    return f'/services/{slug}' if slug in ['hormone-optimization', 'neuropathy', 'pain-relief', 'pelvic-floor-incontinence', 'regenerative-medicine'] else f'/{slug}'


def html_record(route, surface):
    elements = [(tag, dict(attrs)) for tag, attrs in surface['elements']]
    ids = [attrs['id'] for tag, attrs in elements if 'id' in attrs]
    images = []
    for attrs in surface['images']:
        url = attrs.get('src', '')
        decoded = parse_qs(urlparse(url).query).get('url', [url])[0]
        images.append({'src': decoded, 'alt': attrs.get('alt'), 'exists': (ROOT / 'public' / unquote(decoded).lstrip('/')).is_file() if decoded.startswith('/') else None})
    headings = sum(tag == 'h1' for tag, attrs in elements)
    buttons = [attrs for tag, attrs in elements if tag == 'button']
    return {'route': route, 'h1_count': headings, 'robots': surface['robots'],
        'section_ids': [attrs.get('id') for tag, attrs in elements if tag == 'section'],
        'duplicate_ids': sorted({item for item in ids if ids.count(item) > 1}),
        'images': images, 'missing_image_alt': sum(image['alt'] is None for image in images),
        'raw_submit_buttons': [b for b in buttons if b.get('type') == 'submit'],
        'form_count': sum(tag == 'form' for tag, attrs in elements),
        'empty_links': [a for tag, a in elements if tag == 'a' and a.get('href', '') in ('', '#')],
        'text': surface['text']}


def inventory():
    expected = ['/'] + [route_for(s) for s in DESIGNED] + [f'/{s}' for s in UTILITIES]
    declared = {'/' + '/'.join(p.relative_to(ROOT / 'app').parts[:-1]).replace('(batch-three)/', '').replace('(utility)/', ''): str(p.relative_to(ROOT)) for p in (ROOT / 'app').rglob('page.tsx')}
    surfaces = json.loads(json.dumps(MODULE.capture()))
    records = [html_record(route, surfaces['index.html' if route == '/' else route.lstrip('/') + '.html']) for route in expected]
    issues = [r['route'] for r in records if r['h1_count'] != 1 or r['duplicate_ids'] or r['missing_image_alt'] or r['raw_submit_buttons'] or r['empty_links'] or any(i['exists'] is False for i in r['images'])]
    gated = [r for r in records if r['route'].lstrip('/') in UTILITIES + ['book', 'educational-guide']]
    noindex = all(any('noindex' in value for value in r['robots']) and r['form_count'] == 0 for r in gated)
    original = json.loads((PRIOR / 'html-after.json').read_text())
    protected = ['index.html', 'variant-a.html', 'variant-b.html'] + [slug + '.html' for slug in UTILITIES]
    comparison = {name: original[name] == surfaces[name] for name in protected}
    write('route-inventory.json', {'status': 'PASS' if len(expected) == 15 and set(expected) <= set(declared) and noindex else 'FAIL',
        'approved_routes': expected, 'declared_routes': declared, 'all_fifteen_declared': set(expected) <= set(declared),
        'six_gated_noindex_pages': noindex, 'protected_html_equal_to_initial': comparison,
        'html_check_status': 'PASS' if not issues else 'FAIL', 'html_issues': issues, 'records': records,
        'limitations': 'HTML checks cannot certify painted typography, crops, focus visibility, responsive overflow or fidelity. Contact metadata remains indexable in the exact authorized implementation.'})
    print('Inventory:', len(expected), 'approved routes; HTML issues:', issues, '; six gated/noindex:', noindex)


def integrity():
    evidence = {name: sha(ROOT / name) == value for name, value in INITIAL['sha256'].items() if name.startswith('site_convergence/pr40-source-contract-audit/') or name == 'AGENTS.md'}
    retired = json.loads((OUT / 'retirement-receipt.json').read_text())
    archives = {row['previous_path']: row['archive_path'] for row in retired}
    images = {name: sha(ROOT / archives.get(name, name)) == value for name, value in INITIAL['initial_source_asset_hashes'].items() if Path(name).suffix.lower() in {'.png', '.jpg', '.jpeg', '.webp', '.avif', '.svg'}}
    receipts = json.loads((OUT / 'integration-receipt.json').read_text())
    code = {r['path']: sha(ROOT / r['path']) == r['sha256'] for r in receipts if r['path'].startswith(('app/', 'src/'))}
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    allowed = set(json.loads((OUT / 'integration-plan.json').read_text())['paths']) | set(archives) | {'src/components/batch-three/design-photo.tsx', 'src/components/interior/interior-image.tsx'}
    violations = sorted(set(changed) - allowed)
    book_before = subprocess.check_output(['git', 'show', 'HEAD:app/(batch-three)/batch-three.css'], cwd=ROOT, text=True).splitlines()
    book_now = (ROOT / 'app/(batch-three)/batch-three.css').read_text().splitlines()
    book_css = all(line in book_now for line in book_before if '.b3-book-' in line or '.b3-calendar-' in line)
    tracked = subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT, text=True).splitlines()
    bad_dependencies = [line for line in tracked if '/node_modules/' in line or line.startswith('120000 ')]
    write('integrity.json', {'status': 'PASS' if all(evidence.values()) and all(images.values()) and all(code.values()) and not violations and book_css and not bad_dependencies else 'FAIL',
        'prior_evidence_and_agents_unchanged': evidence, 'all_original_image_bytes_unchanged': images,
        'exact_authorized_successor_code': code, 'unexpected_tracked_changes': violations,
        'all_initial_book_css_lines_preserved': book_css, 'tracked_dependencies_or_symlinks': bad_dependencies,
        'real_local_node_modules': (ROOT / 'node_modules').is_dir() and not (ROOT / 'node_modules').is_symlink(),
        'head_unchanged': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == INITIAL['head'].strip()})
    print('Integrity:', not violations, 'Book CSS preserved:', book_css, 'exact successor code:', all(code.values()))


if __name__ == '__main__':
    inventory()
    integrity()
