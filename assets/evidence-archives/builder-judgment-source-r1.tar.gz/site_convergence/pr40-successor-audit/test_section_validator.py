"""Run the installed section-validator regressions with local temporary fixtures."""
import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
TEST = Path('/var/lib/megaclaw/workspace/skills/website-orchestrator/scripts/tests/test_validate_section_implementation.py')
SPEC = importlib.util.spec_from_file_location('external_section_tests', TEST)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def run():
    passed = []
    for name in sorted(vars(MODULE)):
        if not name.startswith('test_'):
            continue
        with tempfile.TemporaryDirectory(dir=OUT) as directory:
            getattr(MODULE, name)(Path(directory))
        passed.append(name)
    result = {'status': 'PASS', 'test_source': str(TEST), 'test_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(), 'tests': passed}
    (OUT / 'section-regression-tests.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS', len(passed), 'installed section-validator regressions')


if __name__ == '__main__':
    run()
