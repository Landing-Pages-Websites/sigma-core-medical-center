# PR40 candidate source-contract reconciliation

This in-repo handoff describes the requested branch. It is builder-owned evidence, not approval or a source PASS.
Research input: `/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a/design_assets/pages/contact/NOTES.md` (SHA-256 `ad72f0cff5e0e522c62b94c1171c45a7d4be9005961d5e55736699cf15097300`).

Mapped candidate assets: 1; runtime assets: 2; unresolved CODE/raster conflicts: 1.
Every original research frame, region, verdict, asset_file, provenance and recipe is preserved. Added client-copy regions are explicit round2 deviations, not successor-frame extractions.
Inherited research notes below describe their own successor checkout. Their zero-runtime/approval/review statements do not establish facts about this PR40 candidate.

The scanner ignores reuse_intent and requires forbidden CLI exemptions for duplicates. Its unbypassed result remains authoritative; this document grants no exemption.

- `01-contact-hero`: source expects 0, candidate maps 0, runtime uses 0.
- `02-verified-location-details`: source expects 0, candidate maps 0, runtime uses 0.
- `03-facility-image`: source expects 0, candidate maps 1, runtime uses 1.
  - CLIENT COPY `03-facility-image-01-real-waiting-room.png`: Authentic facility orientation beneath the Contact caveat, native top steps, rail/bracket and 96px desktop bottom gap; not location verification. Reuse: Owner 03-facility-image in src/components/batch-three/contact/facility.tsx: Authentic facility orientation beneath the Contact caveat, native top steps, rail/bracket and 96px desktop bottom gap; not location verification. This section uses the same supplied waiting-room view as About gallery, Contact facility and the live home place-of-care section. About inventories the two distinct supplied room views; Contact orients the visit-status section; Home introduces the place of care. Reuse conveys the same room and never a second location or a verified address.
- `04-booking-cta`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `contact/04-booking-cta-01-clinic-reception.png` in `src/components/batch-three/contact/booking.tsx`: research requires CODE; still rendered. No fake asset_file was added.

## Preserved research NOTES.md (upstream scope only)

# Contact local staged handoff r1

The local effective contract is the independently reviewed contact-r1 successor. The immutable native and implementation reviews are recorded in section_manifest.json local_effective_handoff, including their hashes. Historical candidate statuses in copied contracts remain producer-era provenance. All canonical fidelity, QA and edge gates remain pending; no flag is promoted.

All 24 regions are CODE: 5 hero, 4 details, 9 visit, 6 closing. Their complete original build_note recipes are retained verbatim in both extraction-plan mirrors. Four exact reviewed native frames and the exact page stitch are reference material only. Application source is unchanged and Contact content uses zero runtime rasters. No rerender occurred.

Use the observed approximately 55% desktop register value start, with shared baselines and stacked mobile pairs. The historical successor map says 58–64%; its x129–1407 register and x828 values imply 54.695%. Both independent reviews support the 55/45 extraction recipe and existing implementation. Only the local effective map is clarified; its prior text and original hash remain recorded.

The native review is CANDIDATE_KEEP_PENDING_IMPLEMENTATION. The subsequent independent review is LOCAL_IMPLEMENTATION_KEEP_PENDING_HANDOFF_AND_SITE_GATES at f5916fb1c9432282ab6ca07a080881799bf5ac92. Its KEEP applies to composition, with recorded spacing qualifications. It is not DIRECTOR_APPROVED, SHIP_READY, source-gate closure, canonical fidelity PASS, or permission to retire assets. Per-section evidence records those findings while retaining every original fidelity PENDING status.

Contact stays noindex, follow. Public address, phone/email, opening hours, directions and parking/accessibility remain pending. Inherited brand address/opening-date/photo assertions are archival and cannot populate visible copy, metadata, structured data or hidden runtime data. Book scheduling remains unavailable. The five anchors are information navigation only; destination pages and shared chrome are outside this scoped approval.

The strict CODE-only sheet reviews the successor's declared empty runtime asset set. It does not certify the complete public asset directory: two old stored rasters remain there and fail the full-directory strict sheet and unbypassed source audit. They remain registry dependencies. All 51 unresolved assets remain in the ledger; Book is the sole overall audit pass. The old sheet, resources, native refs and contracts are preserved byte-exact in the nonpublic staged-before archive.

Stored-copy disclosure: the retained Contact waiting-room file equals Home public/images/shared/waiting-room.png, About public/images/design/about/03-facility-gallery-02-client-waiting-room.png and the supplied waiting-room source. Home owns the live place-of-care occurrence; Contact links to it. The dead Variant A footer source reference is preserved. The shared reception-2 copy and About reception remain public. Duplicate-content scanner PASS counts implementation references and does not certify uniqueness among stored copies. Booking reception has no other exact-byte match in the prior public/supplied-source scan; differently encoded or visually similar images are not ruled out.

All 14 edge flags remain false and all 14 QA verdicts remain PENDING. Formal 1536x1024 and 1728x1117 convergence, remote evidence, wider painted-edge work, comprehensive accessibility and Site Review remain open. The fresh local browser regression only checks preservation. Clinical, legal, customer and publication readiness are not established.

External canonical promotion and a registry assets-only change remain controller steps, blocked until validated. The separate research-root registry proposal is not applied. Raster archival is a later controller-reviewed task. NO RASTER RETIREMENT or registry/canonical modification occurred.
