# PR40 candidate source-contract reconciliation

This in-repo handoff describes the requested branch. It is builder-owned evidence, not approval or a source PASS.
Research input: `/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a/design_assets/pages/pain-relief/NOTES.md` (SHA-256 `d6ba224354f93b14e43bf401dad65ce59e97c9a1dd5b5f5e0b3fa4167d943b10`).

Mapped candidate assets: 3; runtime assets: 13; unresolved CODE/raster conflicts: 10.
Every original research frame, region, verdict, asset_file, provenance and recipe is preserved. Added client-copy regions are explicit round2 deviations, not successor-frame extractions.
Inherited research notes below describe their own successor checkout. Their zero-runtime/approval/review statements do not establish facts about this PR40 candidate.

The scanner ignores reuse_intent and requires forbidden CLI exemptions for duplicates. Its unbypassed result remains authoritative; this document grants no exemption.

- `01-hero.png`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `pain-relief/01-hero-01-person-walking.png` in `src/components/interior/pain-relief/hero.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `02-pain-concern-navigation.png`: source expects 0, candidate maps 0, runtime uses 3.
  - UNRESOLVED `pain-relief/02-pain-concern-navigation-01-knee-clinic.png` in `src/components/interior/pain-relief/navigation.tsx`: research requires CODE; still rendered. No fake asset_file was added.
  - UNRESOLVED `pain-relief/02-pain-concern-navigation-02-low-back-clinic.png` in `src/components/interior/pain-relief/navigation.tsx`: research requires CODE; still rendered. No fake asset_file was added.
  - UNRESOLVED `pain-relief/02-pain-concern-navigation-03-neck-clinic.png` in `src/components/interior/pain-relief/navigation.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `03-knee-concerns.png`: source expects 1, candidate maps 1, runtime uses 1.
- `04-low-back-concerns.png`: source expects 1, candidate maps 1, runtime uses 1.
- `05-neck-concerns.png`: source expects 1, candidate maps 1, runtime uses 2.
  - UNRESOLVED `pain-relief/05-neck-concerns-02-clinic-lounge-strip.png` in `src/components/interior/pain-relief/neck.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `06-decision-factors.png`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `pain-relief/06-decision-factors-01-clinic-reception.png` in `src/components/interior/pain-relief/decisions.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `07-faq.png`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `pain-relief/07-faq-01-clinic-interior.png` in `src/components/interior/pain-relief/faq.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `08-booking-cta.png`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `pain-relief/08-booking-cta-01-clinic-reception.png` in `src/components/interior/pain-relief/booking.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `09-medical-sources.png`: source expects 0, candidate maps 0, runtime uses 2.
  - UNRESOLVED `pain-relief/09-medical-sources-01-clinic-reception.png` in `src/components/interior/pain-relief/sources.tsx`: research requires CODE; still rendered. No fake asset_file was added.
  - UNRESOLVED `pain-relief/09-medical-sources-02-clinic-lounge.png` in `src/components/interior/pain-relief/sources.tsx`: research requires CODE; still rendered. No fake asset_file was added.

## Preserved research NOTES.md (upstream scope only)

# pain-relief — Stage 9b / The Forward Standard

## Source-truth r2 candidate proposal — PENDING independent Art Director review

The approved photo-specific frames, composition map and manifest remain historical input and are stale for the source-truth successor. This route keeps the original knee outdoors, low-back home and face-safe neck reader images. Ten invented facility regions remain code-native replacements and their old PNGs remain on disk pending ownership. R2 moves the full movement statement into the 390×844 first fold, keeps all eight clinician questions, gives the FAQ a scope job and the booking area a preparation/status job, labels `/book` as “View booking status,” and limits the existing low-back MedlinePlus link to an acute example. No appointment submission, facility claim, clinical review or treatment outcome is represented. The implementation fidelity layers remain `PENDING`; the candidate captures and report are under `site_convergence/pain-relief/`.

Source: approved section frames; section manifest wins for content. CSS viewport used for review: 1440×900 laptop and 390×844 mobile. 
Design frames are 1536×864 bitmaps (medical-sources and some privacy/CTA bands are 1536×512). Their CSS viewport and DPR are unknown.
Use approved typography_contract roles h1/display, body and utility; preserve the approved palette_contract tokens ink, surface, action, electric, silver, charcoal and light. CSS owns fields, bars, brackets, beveled rails, labels, buttons and forms. Photography belongs to its section.
No medical outcomes, team identities, credentials, facility contact details, guide delivery or calendar behavior may be inferred from these visual frames.
Visual QA limitation: source frame photography is sometimes visibly clipped by approved geometric fields or other content; the crops preserve only source-visible subject pixels. Do not fabricate occluded parts, enlarge tiny photo strips beyond readable resolution, or present rendered source-frame rooms as verified client photographs. Client-copy assets are identified explicitly below.


## 01-hero

Segmenter found 1 candidate regions; these are not semantic assets.
- CODE r1: Build the hero section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Live movement typography and a continuous CSS line replace the invented branded reception. No person, office or treatment is implied. Retired public PNG retained pending global ownership decision.

## 02-pain-concern-navigation

Segmenter found 3 candidate regions; these are not semantic assets.
- CODE r1: Build the pain concern navigation section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Keep the pain concern navigation horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Keep the pain concern navigation horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Live knee wayfinding with walking, stairs and standing cues replaces the false clinic tile. Retired public PNG retained pending global ownership decision.
- CODE r5: Live low-back wayfinding with sitting, lifting and sleep cues replaces the false corridor tile. Retired public PNG retained pending global ownership decision.
- CODE r6: Live neck wayfinding with turning, desk work and driving cues replaces the false lounge tile. Retired public PNG retained pending global ownership decision.

## 03-knee-concerns

Segmenter found 4 candidate regions; these are not semantic assets.
- CODE r1: Build the knee concerns section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this knee concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Keep the knee concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Keep the knee concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- EXTRACT r5: person-outdoors; 03-knee-concerns-01-person-outdoors.png; crop approved frame, preserve photographed details; no generic substitute. CSS sizes the slot, not the file; keep its remaining annotations live.

## 04-low-back-concerns

Segmenter found 8 candidate regions; these are not semantic assets.
- CODE r1: Recreate this low back concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this low back concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Recreate this low back concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Keep the low back concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r5: Keep the low back concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r6: Keep the low back concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r7: Keep the low back concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r8: Keep this low back concerns panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- EXTRACT r9: man-at-home; 04-low-back-concerns-01-man-at-home.png; crop approved frame, preserve photographed details; no generic substitute. CSS sizes the slot, not the file; keep its remaining annotations live.

## 05-neck-concerns

Segmenter found 7 candidate regions; these are not semantic assets.
- CODE r1: Recreate this neck concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this neck concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Recreate this neck concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Recreate this neck concerns content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r5: Keep the neck concerns horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r6: Render this compact corner, step, mark or icon as inline SVG strokes and CSS pseudo-elements with the sampled electric-blue, silver and navy tokens; keep any enclosed label as live HTML text. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r7: Keep this neck concerns panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- EXTRACT r8: woman-reading; 05-neck-concerns-01-woman-reading.png; crop approved frame, preserve photographed details; no generic substitute. CSS sizes the slot, not the file; keep its remaining annotations live.
- CODE r9: Neck-specific appointment preparation questions replace the false lounge strip; the woman-reading image remains owned by this frame. Retired public PNG retained pending global ownership decision.

## 06-decision-factors

Segmenter found 6 candidate regions; these are not semantic assets.
- CODE r1: Build the decision factors section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this decision factors content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Recreate this decision factors content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Recreate this decision factors content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r5: Keep this decision factors panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r6: Keep this decision factors panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r7: A live clinician-question checklist and code-native movement line replace the false reception image. Retired public PNG retained pending global ownership decision.

## 07-faq

Segmenter found 3 candidate regions; these are not semantic assets.
- CODE r1: Build the faq section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this faq content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Keep this faq panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Live FAQ scope text, source link and bracket geometry replace the false clinic interior. Retired public PNG retained pending global ownership decision.

## 08-booking-cta

Segmenter found 6 candidate regions; these are not semantic assets.
- CODE r1: Build the booking cta section as a semantic CSS grid on its sampled navy, blue, charcoal or mineral field; use live heading, body, links and buttons. Form angled media boundaries with clip-path polygons, and draw measured blue stair bars and bracket corners with repeated CSS pseudo-elements or small inline SVG. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Keep this booking cta panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Keep the booking cta horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Recreate this booking cta content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r5: Keep the booking cta horizontal rail live: use CSS grid or flex children, one-pixel keylines, polygon-corner pseudo-elements and role-specific inline SVG marks; set the actual copy and navigation targets from the approved section manifest. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r6: Render this compact corner, step, mark or icon as inline SVG strokes and CSS pseudo-elements with the sampled electric-blue, silver and navy tokens; keep any enclosed label as live HTML text. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r7: Live appointment-preparation questions and an honest scheduling-status link replace the false reception image. Retired public PNG retained pending global ownership decision.

## 09-medical-sources

Segmenter found 4 candidate regions; these are not semantic assets.
- CODE r1: Recreate this medical sources content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r2: Recreate this medical sources content group with live HTML typography and responsive CSS grid or flex rows; match the sampled navy/blue/mineral field, use squared panels and one-pixel bracket strokes, and use only short geometric inline SVG bar/icon accents. Preserve manifest copy and functional links. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r3: Keep this medical sources panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r4: Keep this medical sources panel in its own CSS grid track with a solid brand field, clipped polygon edge where visible, live heading/body text and one-pixel bracket pseudo-elements; do not bake source-frame words, actions, or privacy claims into an image. Approved typography_contract roles: h1 (display), body and utility; palette_contract tokens: ink, surface, action, electric, silver, charcoal and light.
- CODE r5: Live named MedlinePlus knee, low-back and neck citations replace the false reception crop. Retired public PNG retained pending global ownership decision.
- CODE r6: A live reading-boundary explanation and code-native line replace the false lounge crop. Retired public PNG retained pending global ownership decision.

## Review limitations

- 03-knee-concerns: the source cards occlude the walker above the cropped sidewalk photo. The extracted photo contains only the visible lower-body scene; do not synthesize a full-length subject.
- 05-neck-concerns: the facility strip has limited vertical source resolution. Preserve it as a short band, not a full-height room portrait.
