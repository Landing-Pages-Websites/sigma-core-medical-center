# PR40 candidate source-contract reconciliation

This in-repo handoff describes the requested branch. It is builder-owned evidence, not approval or a source PASS.
Research input: `/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a/design_assets/pages/educational-guide/NOTES.md` (SHA-256 `cbc11b7ac9d104025aaf4c989fe6e0c1c0c76cf3ac5e465507e9c8b9380dab35`).

Mapped candidate assets: 0; runtime assets: 4; unresolved CODE/raster conflicts: 4.
Every original research frame, region, verdict, asset_file, provenance and recipe is preserved. Added client-copy regions are explicit round2 deviations, not successor-frame extractions.
Inherited research notes below describe their own successor checkout. Their zero-runtime/approval/review statements do not establish facts about this PR40 candidate.

The scanner ignores reuse_intent and requires forbidden CLI exemptions for duplicates. Its unbypassed result remains authoritative; this document grants no exemption.

- `01-resource-hero`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `educational-guide/01-resource-hero-01-clinic-interior.png` in `src/components/batch-three/educational-guide/hero.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `02-resource-summary`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `educational-guide/02-resource-summary-01-clinic-reception.png` in `src/components/batch-three/educational-guide/summary.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `03-lead-form`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `educational-guide/03-lead-form-01-clinic-lounge.png` in `src/components/batch-three/educational-guide/availability.tsx`: research requires CODE; still rendered. No fake asset_file was added.
- `04-privacy-note`: source expects 0, candidate maps 0, runtime uses 1.
  - UNRESOLVED `educational-guide/04-privacy-note-01-clinic-reception.png` in `src/components/batch-three/educational-guide/privacy.tsx`: research requires CODE; still rendered. No fake asset_file was added.

## Preserved research NOTES.md (upstream scope only)

Canonical Guide reference-only closure — 2026-10-01.
Independent KEEP: evidence/director-fallback-r1-art-review.md; closure provenance: provenance/reference-closure-r1.json.
Four accepted owners and page.png are copied from the fallback; the original package is unchanged.
Access549 / stitch2309; CSS144 / raster144.375; Q4 exact bytes and terminal112 remain.
21 CODE roles, zero production raster assets, no facility photography. Four stable section IDs and five source links remain; unavailable, no requests/signup, noindex,follow, sitemap exclusion remain exact.
No runtime/registry/route/asset-retirement/scanner/Git/remote change or Site Review approval. Fresh controller independent source-contract verification is next; runtime implementation remains old until separately reviewed.
page-draft.png and prompts/ are preserved history only; they impose no current copy, imagery or generation obligation.
All relative evidence paths below resolve against design_refs/pages/educational-guide. The legacy design_assets Guide records are refreshed copies of this package.

Historical fallback capture record (verbatim; candidate/pending/no-promotion statements describe the pre-closure state):
Director fallback r1 — rendered candidate; acceptance pending fresh independent review.
Authority: director8d4d0cbd; controller explicitly adopted review lines19–26 fallback. Pre-render amendment, manifest and targets were recorded together; hashes are in provenance/pre-render-contract.json.
Access native549=ceil548.625, observed rail492.625, natural CSS exit56+privacy entry88=144; native raster interval144.375 includes exactly0.375 rounding. This supersedes the isolated560/504 exact raster targets and derived stitch/interval only; source/runtime geometry and visual gates remain.
The only rendered CSS delta is two body[data-owner] background declarations: hero/summary #0666a5 and access #f7f6f3. Privacy #20272e stays unchanged. No section movement, spacer, forced height/padding, transform, screenshot crop/resize/raster fill.
One local Chromium153.0.8010.12 launch captured Q1–Q3 full CSS viewports1536×624/624/549, DPR1, CSS screenshot scale. Working aptlib+syslibs LD_LIBRARY_PATH; no external browser requests or generative calls. Source Sans3 weights400/600 loaded; CDP confirms custom Source Sans3/Source Sans3 SemiBold.
Q4 is original1536×512 KEEP reused byte for byte, not a fresh capture; provenance/q4-preserved.json contains source/hash/original geometry/font evidence. Native privacy budget88+224+88+112 remains.
Natural heights615.890625/611.65625/548.625/400, every recorded section/region/text bound, geometry/style, text/link/control record and copied HTML match the old candidate. Content pixels above fractional section boundaries are identical; source components/CSS and original candidate hashes remain unchanged.
Exact unscaled1536×2309 stitch and fresh1536×512 seam bands at624/1248/1797 pass owner and last256/first256 pixel equality. All four full owners, three bands and whole stitch were visually inspected by this worker; no clipped owner content or neighboring chrome observed. Unintended white reference-canvas strips are absent; intended blue/mineral/charcoal body canvas remains.
Fresh worker continuity classifications CONTINUOUS/HARD_TRANSITION/HARD_TRANSITION are PASS; official seam_tools.py validator exit0 checks ledger status and before/after evidence. Original before bands stay in the old candidate; after bands are fresh. This is not independent art acceptance.
Composition map/extraction plan contain21 CODE boxes:17 from three fresh captures,4 from original Q4 observations with exact reused pixels; all21 pixel samples recomputed. Boxes are DOM extents, not tight glyph silhouettes; no production raster assets.
Hero navy hierarchy,54px action and420×160 open motif remain. Summary columns,28px book,32px caveat gap, three complete rows and adjoining service panel remain. Access card42/rail separation32 remain. Privacy statement/caveat/complete Contact action remain.
Old candidate retained in full; historical provenance copied separately. No canonical/registry/implementation contracts/retirement/Git/remotes/source/runtime mutations. Runtimef4390378, PR40draft452fa6f and44assets/14falseflags/20Guidepending are supplied context, not reaudited.
Fresh independent review is the controller’s next step; no promotion or further capture is performed.
