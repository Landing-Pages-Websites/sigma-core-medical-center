# pain-relief — authorized successor runtime reconciliation

Implementation source: `8c077d6`. Status: **uncommitted, not approved**.

No Pain Relief successor commit was authorized in the supplied list. Ten current runtime rasters conflict with canonical CODE regions. No fabricated mappings are added.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/pain-relief/extraction_plan.json`; SHA-256 `448cbaf0cdf0e57b2dade6df5a23ebb2da40b35c27312c9bd561e2fbf7ce8ea1`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce pain relief information and its limits.

Owner: `src/components/interior/pain-relief/hero.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 1.

- UNRESOLVED runtime: `pain-relief/01-hero-01-person-walking.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 02-pain-concern-navigation

Explain pain concern navigation as a specific part of the pain relief decision, preserving source-backed copy.

Owner: `src/components/interior/pain-relief/navigation.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 3.

- UNRESOLVED runtime: `pain-relief/02-pain-concern-navigation-01-knee-clinic.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
- UNRESOLVED runtime: `pain-relief/02-pain-concern-navigation-02-low-back-clinic.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
- UNRESOLVED runtime: `pain-relief/02-pain-concern-navigation-03-neck-clinic.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 03-knee-concerns

Explain knee concerns as a specific part of the pain relief decision, preserving source-backed copy.

Owner: `src/components/interior/pain-relief/knee.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 04-low-back-concerns

Explain low back concerns as a specific part of the pain relief decision, preserving source-backed copy.

Owner: `src/components/interior/pain-relief/back.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 05-neck-concerns

Explain neck concerns as a specific part of the pain relief decision, preserving source-backed copy.

Owner: `src/components/interior/pain-relief/neck.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 2.

- UNRESOLVED runtime: `pain-relief/05-neck-concerns-02-clinic-lounge-strip.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 06-decision-factors

Explain decision factors as a specific part of the pain relief decision, preserving source-backed copy.

Owner: `src/components/interior/pain-relief/decisions.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 1.

- UNRESOLVED runtime: `pain-relief/06-decision-factors-01-clinic-reception.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 07-faq

Answer common pain relief questions without diagnosing or promising outcomes.

Owner: `src/components/interior/pain-relief/faq.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 1.

- UNRESOLVED runtime: `pain-relief/07-faq-01-clinic-interior.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 08-booking-cta

Explain scheduling status and next questions about pain relief.

Owner: `src/components/interior/pain-relief/booking.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 1.

- UNRESOLVED runtime: `pain-relief/08-booking-cta-01-clinic-reception.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
## 09-medical-sources

Name the evidence and review boundaries for pain relief.

Owner: `src/components/interior/pain-relief/sources.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 2.

- UNRESOLVED runtime: `pain-relief/09-medical-sources-01-clinic-reception.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.
- UNRESOLVED runtime: `pain-relief/09-medical-sources-02-clinic-lounge.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.

## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.


No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
