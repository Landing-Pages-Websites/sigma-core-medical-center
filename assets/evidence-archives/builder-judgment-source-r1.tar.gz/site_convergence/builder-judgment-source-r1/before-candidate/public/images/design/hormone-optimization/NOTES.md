# hormone-optimization — authorized successor runtime reconciliation

Implementation source: `bec8b99`. Status: **uncommitted, not approved**.

Raster roles match the explicitly authorized source-truth successor.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/hormone-optimization/extraction_plan.json`; SHA-256 `9ed6fd41abe217f749bf1587d5cb7f5c4d382ab87a955c536f812f7fec21f859`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce hormone optimization information and its limits.

Owner: `src/components/interior/hormone-optimization/hero.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 02-visitor-orientation

Orient visitors to the scope and limits of hormone optimization information.

Owner: `src/components/interior/hormone-optimization/orientation.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-goals-and-decision-factors

Help visitors identify personal goals and questions about hormone optimization.

Owner: `src/components/interior/hormone-optimization/goals.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-responsible-next-step

Explain responsible next step as a specific part of the hormone optimization decision, preserving source-backed copy.

Owner: `src/components/interior/hormone-optimization/next-step.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-faq

Answer common hormone optimization questions without diagnosing or promising outcomes.

Owner: `src/components/interior/hormone-optimization/faq.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 06-booking-cta

Explain scheduling status and next questions about hormone optimization.

Owner: `src/components/interior/hormone-optimization/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 07-medical-sources

Name the evidence and review boundaries for hormone optimization.

Owner: `src/components/interior/hormone-optimization/sources.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `hormone-optimization/02-visitor-orientation-01-clinic-reception.png`: former owner `src/components/interior/hormone-optimization/orientation.tsx`, superseded by `bec8b99`; SHA-256 `2882357f7080f3c6214a3c2e8e5af24ffeb73529f46a2c9114cbb224c4ab650f`.
- `hormone-optimization/03-goals-and-decision-factors-01-clinic-interior-strip.png`: former owner `src/components/interior/hormone-optimization/goals.tsx`, superseded by `bec8b99`; SHA-256 `031747c2f0cee0a612da4085f1b15b509ac69a6983119db1054d68f038be0e92`.
- `hormone-optimization/04-responsible-next-step-01-visitor-in-clinic.png`: former owner `src/components/interior/hormone-optimization/next-step.tsx`, superseded by `bec8b99`; SHA-256 `0e571038954ed14074ec42224b0be0e96eb57750c7752f8eb8be6074d6e02205`.
- `hormone-optimization/05-faq-01-clinic-lounge.png`: former owner `src/components/interior/hormone-optimization/faq.tsx`, superseded by `bec8b99`; SHA-256 `bdd48d472d45804a0c92a2ae837313d8f8fae5c2ffee8652d681c1e028e093fc`.
- `hormone-optimization/06-booking-cta-01-clinic-reception.png`: former owner `src/components/interior/hormone-optimization/booking.tsx`, superseded by `bec8b99`; SHA-256 `6ddfa7b23b1a613591b32b44d0e550a1a1a6528f7a9337b55c8da04922903949`.
- `hormone-optimization/07-medical-sources-01-clinic-reception.png`: former owner `src/components/interior/hormone-optimization/sources.tsx`, superseded by `bec8b99`; SHA-256 `35fd5fa8e3a0affc3a844be8cc643473fff034ebaaaf6131cdb7dfa9be1956a3`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
