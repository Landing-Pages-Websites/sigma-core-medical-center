# about — authorized successor runtime reconciliation

Implementation source: `6c98505`. Status: **uncommitted, not approved**.

Canonical About r5 is a newer all-CODE candidate. The explicitly authorized 6c98505 successor retains one client reception photograph. Its branch plan governs this integration; canonical r5 is preserved, not downgraded or relabeled stale.

Contract source: `git:6c98505:public/images/design/about/extraction_plan.json`; SHA-256 `0839fc2e1675a33c9347a7b1880b3073f58ff562690ab1906fa7db39b675816b`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce Sigma Core and the scope of its care information.

Owner: `src/components/batch-three/about/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-clinic-purpose

Explain the clinic purpose and route visitors to service information.

Owner: `src/components/batch-three/about/purpose.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-facility-gallery

Identify one supplied reception view while withholding address and visit verification.

Owner: `src/components/batch-three/about/gallery.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

- Reuse disclosure: About gallery.tsx / 03-facility-gallery identifies the supplied reception with an explicit location caveat. src/components/variant-a/place-of-care.tsx / place-of-care references the identical shared reception-2 photograph as historical premises context, but /variant-a returns notFound. This is a disclosed dormant source occurrence, not an approved live cross-route recurrence or scanner exemption. Contact successor facility contains no photograph; the earlier Contact-reuse statement is superseded.
## 04-care-principles

Explain care principles with live editorial text.

Owner: `src/components/batch-three/about/principles.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-team-publication-gate

State that team details remain unpublished until verified.

Owner: `src/components/batch-three/about/team.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 06-booking-cta

Explain unavailable scheduling and direct visitors to its status.

Owner: `src/components/batch-three/about/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `about/03-facility-gallery-02-client-waiting-room.png`: former owner `src/components/batch-three/about/gallery.tsx`, superseded by `6c98505`; SHA-256 `cc8361272c7ba3468fa25bb18ae8d7a9938a25b8f7bffad3f912670e4ad62353`.
- `about/04-care-principles-01-clinic-signage.png`: former owner `src/components/batch-three/about/principles.tsx`, superseded by `6c98505`; SHA-256 `7f5307021a14fdfb75c2f68d5a166b7f26e207cfddfe0d9ae7db75862902c63b`.
- `about/04-care-principles-02-clinic-lounge.png`: former owner `src/components/batch-three/about/principles.tsx`, superseded by `6c98505`; SHA-256 `a4c51579fabb35be081fb3b7efde92d10c2b08af4e534de308d3e09311fa10bd`.
- `about/05-team-publication-gate-01-clinic-reception.png`: former owner `src/components/batch-three/about/team.tsx`, superseded by `6c98505`; SHA-256 `b7318e7d5a09100d21ec9557d80558d53f16788628544b2c1288b57c687db54b`.
- `about/06-booking-cta-01-clinic-reception.png`: former owner `src/components/batch-three/about/booking.tsx`, superseded by `6c98505`; SHA-256 `9be1e535d846de0beed1c73e0b793a066e8a66d0909023cfc4668b24b4bebda7`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
