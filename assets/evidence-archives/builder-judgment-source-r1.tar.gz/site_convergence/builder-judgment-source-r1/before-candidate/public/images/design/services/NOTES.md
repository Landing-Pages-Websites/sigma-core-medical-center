# services — authorized successor runtime reconciliation

Implementation source: `afb37ce`. Status: **uncommitted, not approved**.

Raster roles match the explicitly authorized source-truth successor.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/services/extraction_plan.json`; SHA-256 `5ba832922eaf37c3572bb93d8577c93fc6946ef1f0f2c26e3ecbd86e0609b49f`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce the service categories through code-native wayfinding.

Owner: `src/components/interior/services/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-neuropathy-feature

Orient visitors to neuropathy information with the approved small walking inset.

Owner: `src/components/interior/services/neuropathy.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 03-service-navigation

Compare service categories with one approved active-couple panel for pain relief.

Owner: `src/components/interior/services/navigation.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 04-how-to-choose-next-step

Help visitors choose a next information step using live decision text.

Owner: `src/components/interior/services/choose.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-booking-cta

Explain booking status and provide useful lower route links.

Owner: `src/components/interior/services/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `services/01-hero-01-reception.png`: former owner `src/components/interior/services/hero.tsx`, superseded by `afb37ce`; SHA-256 `0763d56641a7e7592e7e2fb0d4e8ef2bb352ffb29fc876c0153e4e55dce36cce`.
- `services/02-neuropathy-feature-02-clinic-reception.png`: former owner `src/components/interior/services/neuropathy.tsx`, superseded by `afb37ce`; SHA-256 `c4a2c732698d72423624f5d67689fd8ea0654c587ff13a0f882c3420d8c18a0d`.
- `services/03-service-navigation-02-clinic-reception.png`: former owner `src/components/interior/services/navigation.tsx`, superseded by `afb37ce`; SHA-256 `4ec0c4a2148dc96b4085ba56911c776eb6fbe4ffeecdcdbf4bed52334c865fe3`.
- `services/04-how-to-choose-next-step-01-clinic-reception.png`: former owner `src/components/interior/services/choose.tsx`, superseded by `afb37ce`; SHA-256 `187221ed3c3be33300521b92158bab1a36ad214a6ae2863df8a5953d33205e33`.
- `services/05-booking-cta-01-clinic-reception.png`: former owner `src/components/interior/services/booking.tsx`, superseded by `afb37ce`; SHA-256 `43231cdf32147636dad538e54f1fab0e7e649cc2c5f43935356f4fe680ce7c0b`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
