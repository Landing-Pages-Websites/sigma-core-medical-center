# contact — authorized successor runtime reconciliation

Implementation source: `6c98505`. Status: **uncommitted, not approved**.

Canonical Contact is a newer zero-raster candidate. The authorized foundation changes the facility section but still renders the older booking-room raster. No replacement for that booking component is in the authorized chain.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/contact/extraction_plan.json`; SHA-256 `7f4828f20ca9aa5b8e1bcf5ba0edfe6950408dc7cbb4b75696faadb52d9112b8`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-contact-hero

Orient visitors to Richmond-area contact information pending verification.

Owner: `src/components/batch-three/contact/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-verified-location-details

Withhold unverified address and public contact details.

Owner: `src/components/batch-three/contact/details.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-facility-image

Explain the unverified visit status using live text and code-native geometry.

Owner: `src/components/batch-three/contact/facility.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-booking-cta

Explain unavailable appointment scheduling; legacy reception raster remains an unresolved contract conflict.

Owner: `src/components/batch-three/contact/booking.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 0; runtime rasters: 1.

- UNRESOLVED runtime: `contact/04-booking-cta-01-clinic-reception.png`. Canonical CODE contract supplies no approval; no asset_file mapping invented.

## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `contact/03-facility-image-01-real-waiting-room.png`: former owner `src/components/batch-three/contact/facility.tsx`, superseded by `6c98505`; SHA-256 `cc8361272c7ba3468fa25bb18ae8d7a9938a25b8f7bffad3f912670e4ad62353`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
