# pelvic-floor-incontinence — authorized successor runtime reconciliation

Implementation source: `0780261`. Status: **uncommitted, not approved**.

Raster roles match the explicitly authorized source-truth successor.

Contract source: `git:0780261:public/images/design/pelvic-floor-incontinence/extraction_plan.json`; SHA-256 `401c37a3f06af4a1ce2bda98fe52aedea20ca08201f4f2f5e73cae375bb6bab6`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce pelvic floor incontinence information and its limits.

Owner: `src/components/interior/pelvic-floor-incontinence/hero.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 02-private-orientation

Orient visitors to the scope and limits of pelvic floor incontinence information.

Owner: `src/components/interior/pelvic-floor-incontinence/orientation.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-concerns-and-goals

Help visitors identify personal goals and questions about pelvic floor incontinence.

Owner: `src/components/interior/pelvic-floor-incontinence/goals.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-what-to-expect

Explain preparation and verification boundaries for a pelvic floor incontinence conversation.

Owner: `src/components/interior/pelvic-floor-incontinence/expect.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-faq

Answer common pelvic floor incontinence questions without diagnosing or promising outcomes.

Owner: `src/components/interior/pelvic-floor-incontinence/faq.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 06-booking-cta

Explain scheduling status and next questions about pelvic floor incontinence.

Owner: `src/components/interior/pelvic-floor-incontinence/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 07-medical-sources

Name the evidence and review boundaries for pelvic floor incontinence.

Owner: `src/components/interior/pelvic-floor-incontinence/sources.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `pelvic-floor-incontinence/02-private-orientation-01-clinic-lounge.png`: former owner `src/components/interior/pelvic-floor-incontinence/orientation.tsx`, superseded by `0780261`; SHA-256 `1c294472b3081ecb6c9554cbcc80bd10c3951e25d85ecd29066f25d5d0022e1d`.
- `pelvic-floor-incontinence/03-concerns-and-goals-01-clinic-reception.png`: former owner `src/components/interior/pelvic-floor-incontinence/goals.tsx`, superseded by `0780261`; SHA-256 `483dc695fb9f04332e0dede63b895e2d349a524a19bb76939c9bacf9d1c177b1`.
- `pelvic-floor-incontinence/05-faq-01-clinic-lounge.png`: former owner `src/components/interior/pelvic-floor-incontinence/faq.tsx`, superseded by `0780261`; SHA-256 `daa0d4a32e3c8c68bb01761ca34b7b55412fcd1d2185b19f970c026aa78a4336`.
- `pelvic-floor-incontinence/06-booking-cta-01-clinic-reception.png`: former owner `src/components/interior/pelvic-floor-incontinence/booking.tsx`, superseded by `0780261`; SHA-256 `e38ba3de785ac327f8b1ede8e3a832f5959acb91f20956e654db94fa58b5132a`.
- `pelvic-floor-incontinence/06-booking-cta-02-clinic-lounge.png`: former owner `src/components/interior/pelvic-floor-incontinence/booking.tsx`, superseded by `0780261`; SHA-256 `1ed15524531d727a1dc97ce716201f9272ed93e1b2bfd3e2af15fe6ee9b95e40`.
- `pelvic-floor-incontinence/07-medical-sources-01-clinic-lounge.png`: former owner `src/components/interior/pelvic-floor-incontinence/sources.tsx`, superseded by `0780261`; SHA-256 `66898a3e06e08b7322478c0953e7bee42890ddf91b46bdedfc66d465d168b01a`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
