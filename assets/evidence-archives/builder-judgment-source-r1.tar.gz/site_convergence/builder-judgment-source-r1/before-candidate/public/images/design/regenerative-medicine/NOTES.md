# regenerative-medicine — authorized successor runtime reconciliation

Implementation source: `ac9296b`. Status: **uncommitted, not approved**.

Raster roles match the explicitly authorized source-truth successor.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/regenerative-medicine/extraction_plan.json`; SHA-256 `2fcac8029b5580ad041d580103d87d08e96cbdd402ee140eb7e72d5357a31809`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce regenerative medicine information and its limits.

Owner: `src/components/interior/regenerative-medicine/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-category-orientation

Orient visitors to the scope and limits of regenerative medicine information.

Owner: `src/components/interior/regenerative-medicine/orientation.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-questions-for-a-consultation

Explain questions for a consultation as a specific part of the regenerative medicine decision, preserving source-backed copy.

Owner: `src/components/interior/regenerative-medicine/questions.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-decision-factors

Explain decision factors as a specific part of the regenerative medicine decision, preserving source-backed copy.

Owner: `src/components/interior/regenerative-medicine/decisions.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-faq

Answer common regenerative medicine questions without diagnosing or promising outcomes.

Owner: `src/components/interior/regenerative-medicine/faq.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 06-booking-cta

Explain scheduling status and next questions about regenerative medicine.

Owner: `src/components/interior/regenerative-medicine/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 07-medical-sources

Name the evidence and review boundaries for regenerative medicine.

Owner: `src/components/interior/regenerative-medicine/sources.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `regenerative-medicine/01-hero-01-clinic-reception.png`: former owner `src/components/interior/regenerative-medicine/hero.tsx`, superseded by `ac9296b`; SHA-256 `921f8dba482de21ae74cc4b68ed2c894672e4fb114594cb82644b3acf66205a9`.
- `regenerative-medicine/03-questions-for-a-consultation-01-clinic-interior-strip.png`: former owner `src/components/interior/regenerative-medicine/questions.tsx`, superseded by `ac9296b`; SHA-256 `33c6e76d48e5b5093ac0529df2b00c848db11e49871f7db61c13e59293ba0235`.
- `regenerative-medicine/04-decision-factors-01-clinic-left.png`: former owner `src/components/interior/regenerative-medicine/decisions.tsx`, superseded by `ac9296b`; SHA-256 `594334e2ae3e79296cd80f4a131b6ff03b2782ba8c46c3254d66f61d186de3c0`.
- `regenerative-medicine/04-decision-factors-02-clinic-right.png`: former owner `src/components/interior/regenerative-medicine/decisions.tsx`, superseded by `ac9296b`; SHA-256 `08958944e8d2edcb11c21e39c29e0ba81e4b459d82d79210a404990e7ffb6eb6`.
- `regenerative-medicine/05-faq-01-clinic-reception.png`: former owner `src/components/interior/regenerative-medicine/faq.tsx`, superseded by `ac9296b`; SHA-256 `f1e0d70108be79afd321b9667dc5b5f338e60f111b17d5191162661183cf9a9b`.
- `regenerative-medicine/06-booking-cta-01-clinic-reception.png`: former owner `src/components/interior/regenerative-medicine/booking.tsx`, superseded by `ac9296b`; SHA-256 `d14077736f2582aa8ecf81c25e14f741fec1494605bef99ee0912e9c80936c5d`.
- `regenerative-medicine/07-medical-sources-01-clinic-lounge.png`: former owner `src/components/interior/regenerative-medicine/sources.tsx`, superseded by `ac9296b`; SHA-256 `7b0f940c4b8fd111e8dcca63cbec1c841dca4dda8e7b571f84ae6c16db8f777f`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
