# neuropathy — authorized successor runtime reconciliation

Implementation source: `71d5838`. Status: **uncommitted, not approved**.

Raster roles match the explicitly authorized source-truth successor.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/neuropathy/extraction_plan.json`; SHA-256 `0b308deeddaa4846e644af7c773c2fa8d3f9d38bc6e67ed5ffee29d7f52767af`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-hero

Introduce neuropathy information and its limits.

Owner: `src/components/interior/neuropathy/hero.tsx`. Actual treatment: mixed live HTML and raster.
Mapped rasters: 1; runtime rasters: 1.

## 02-visitor-orientation

Orient visitors to the scope and limits of neuropathy information.

Owner: `src/components/interior/neuropathy/orientation.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-goals-and-decision-factors

Help visitors identify personal goals and questions about neuropathy.

Owner: `src/components/interior/neuropathy/goals.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-what-to-expect

Explain preparation and verification boundaries for a neuropathy conversation.

Owner: `src/components/interior/neuropathy/expect.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 05-faq

Answer common neuropathy questions without diagnosing or promising outcomes.

Owner: `src/components/interior/neuropathy/faq.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 06-booking-cta

Explain scheduling status and next questions about neuropathy.

Owner: `src/components/interior/neuropathy/booking.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 07-medical-sources

Name the evidence and review boundaries for neuropathy.

Owner: `src/components/interior/neuropathy/sources.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `neuropathy/02-visitor-orientation-01-clinic-interior.png`: former owner `src/components/interior/neuropathy/orientation.tsx`, superseded by `71d5838`; SHA-256 `b2a09cadc8ab7e896e29be82981d1c4ba0c7dfd13428f157e1ec0a8db8838bd2`.
- `neuropathy/03-goals-and-decision-factors-01-clinic-reception.png`: former owner `src/components/interior/neuropathy/goals.tsx`, superseded by `71d5838`; SHA-256 `654343d6e054b2bff7abd38c819e3c73a3a15c21a1b7500fe4f5d5d69231088f`.
- `neuropathy/03-goals-and-decision-factors-02-visitor-in-lounge.png`: former owner `src/components/interior/neuropathy/goals.tsx`, superseded by `71d5838`; SHA-256 `bd624882a2b7908f630d6ad22940051fc143bc8177a23f03842e3380058867f6`.
- `neuropathy/05-faq-01-clinic-lounge.png`: former owner `src/components/interior/neuropathy/faq.tsx`, superseded by `71d5838`; SHA-256 `3264c18e442ba183f0098748554ffd7282f1b05521ac42f01214e8468dadc324`.
- `neuropathy/06-booking-cta-01-visitor-in-clinic.png`: former owner `src/components/interior/neuropathy/booking.tsx`, superseded by `71d5838`; SHA-256 `60852876568d9bf40a6533c3d9f3b4f82685f16263acef78d589dfa571d81f91`.
- `neuropathy/07-medical-sources-01-clinic-lounge.png`: former owner `src/components/interior/neuropathy/sources.tsx`, superseded by `71d5838`; SHA-256 `6d910cc8e7e700b192fd23e6406b2b78fa6ad42ba2845e36b368a6aacff33ec8`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
