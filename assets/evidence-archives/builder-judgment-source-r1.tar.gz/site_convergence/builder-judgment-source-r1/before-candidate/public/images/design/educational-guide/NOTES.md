# educational-guide — authorized successor runtime reconciliation

Implementation source: `6c98505`. Status: **uncommitted, not approved**.

Canonical Guide reference-only KEEP is not a live approval of this authorized 6c98505 implementation. Both use CODE; source-reference measurements are retained as reference evidence only.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/educational-guide/extraction_plan.json`; SHA-256 `8d83248ef6850b93bcbb6d5dbae2c2b44f5a0e9d0194f0d28795404ea5ae98cc`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-resource-hero

State that the educational resource is unavailable and link to services.

Owner: `src/components/batch-three/educational-guide/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-resource-summary

Explain what source information exists without offering an unapproved download.

Owner: `src/components/batch-three/educational-guide/summary.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-lead-form

Keep resource delivery gated; no form, video or download is offered.

Owner: `src/components/batch-three/educational-guide/availability.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 04-privacy-note

Explain privacy and contact boundaries without collecting information.

Owner: `src/components/batch-three/educational-guide/privacy.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `educational-guide/01-resource-hero-01-clinic-interior.png`: former owner `src/components/batch-three/educational-guide/hero.tsx`, superseded by `6c98505`; SHA-256 `b1cf7313973aa2b4ba3d2f22227c649f5e8a4cd444aa3e2df41f790c2f17b598`.
- `educational-guide/02-resource-summary-01-clinic-reception.png`: former owner `src/components/batch-three/educational-guide/summary.tsx`, superseded by `6c98505`; SHA-256 `96cf4b75d97e516612af8b8f5470b9b91b61fcaffa4525b957582e41c12f69ad`.
- `educational-guide/03-lead-form-01-clinic-lounge.png`: former owner `src/components/batch-three/educational-guide/availability.tsx`, superseded by `6c98505`; SHA-256 `983c7af0854da218a7356c4dcf444f9a1c15eb5d6bbdde3dc1988c457e740684`.
- `educational-guide/04-privacy-note-01-clinic-reception.png`: former owner `src/components/batch-three/educational-guide/privacy.tsx`, superseded by `6c98505`; SHA-256 `7549fe24a7bccba9a2bc364e12c4a9a3313137f6335e0d7afcd79ab572bee2b1`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
