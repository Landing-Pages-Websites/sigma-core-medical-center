# book — authorized successor runtime reconciliation

Implementation source: `6c98505`. Status: **uncommitted, not approved**.

Canonical Book describes a later reviewed successor, not the authorized 4ff1fff/6c98505 runtime. Both are all-CODE; its KEEP and exact composition claims do not transfer to this candidate.

Contract source: `site_convergence/pr40-successor-audit/research-inputs/design_assets/pages/book/extraction_plan.json`; SHA-256 `d1c761800d5b304fd6ddbafecde6608fd51977a385c48d94b09ef8649a4471fc`.

Original canonical and predecessor plans/NOTES are preserved byte-for-byte under `site_convergence/pr40-successor-audit/`. No source review claim is promoted to runtime approval.

## 01-booking-hero

Explain online scheduling is unavailable without accepting appointment requests.

Owner: `src/components/batch-three/book/hero.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 02-gohighlevel-calendar

Show an inactive calendar and explain the next available information paths.

Owner: `src/components/batch-three/book/calendar.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.

## 03-privacy-note

State privacy and emergency boundaries without collecting data.

Owner: `src/components/batch-three/book/privacy.tsx`. Actual treatment: code-native live HTML/CSS/SVG.
Mapped rasters: 0; runtime rasters: 0.


## Preserved non-use evidence

The following former runtime files are preserved byte-for-byte, with original basenames, under assets/retired-photo-roles/pr40-successor. The authorized successor no longer renders them. retirement-receipt.json records reversible paths and hashes. No active comparison input was relocated.

- `book/01-booking-hero-01-clinic-reception.png`: former owner `src/components/batch-three/book/hero.tsx`, superseded by `6c98505`; SHA-256 `7bf2ffebb5bbeb6e2e7388eb62e043abb48aefab8facb5edbefd1095e5fa77fd`.
- `book/02-gohighlevel-calendar-01-clinic-lounge.png`: former owner `src/components/batch-three/book/calendar.tsx`, superseded by `6c98505`; SHA-256 `51b1ddba2d204ac7f6fe8470b19abbadefad5a68c5e922d3b5afacec38fdc533`.

No active photo URL or bytes, perceptual input, source approval, allow flag, edge flag or visual status was altered by retirement.
