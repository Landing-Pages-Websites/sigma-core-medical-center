"""Bounded stdlib/Pillow runner; never writes to the installed scanner checkout."""
import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
TEST = Path('/var/lib/megaclaw/workspace/skills/website-orchestrator/scripts/tests/test_audit_design_handoff.py')
SPEC = importlib.util.spec_from_file_location('external_audit_tests', TEST)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def regression_tests():
    passed = []
    for name in sorted(vars(MODULE)):
        if name.startswith('test_'):
            with tempfile.TemporaryDirectory(dir=OUT) as directory:
                getattr(MODULE, name)(Path(directory))
            passed.append(name)
    return passed


def check_reuse_intent_limitation():
    with tempfile.TemporaryDirectory(dir=OUT) as directory:
        paths = MODULE._fixture(Path(directory))
        plan = json.loads(paths['extraction'].read_text())
        plan['frames'][0]['regions'][0]['reuse_intent'] = 'Hero introduces the clinic; footer recalls the same location.'
        paths['extraction'].write_text(json.dumps(plan))
        (paths['source'] / 'Footer.tsx').write_text((paths['source'] / 'Hero.tsx').read_text())
        report = MODULE.MODULE.audit(paths['manifest'], paths['composition'], paths['extraction'], paths['assets'], source_root=paths['source'])
        assert report['checks']['asset_role_reuse'] == 'FAIL'
        return {'plan_reuse_intent_is_consumed': False, 'result': 'FAIL as expected; no allow flags'}


if __name__ == '__main__':
    result = {'status': 'PASS', 'test_source': str(TEST), 'test_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(),
        'installed_regressions_passed': regression_tests(), 'contract_limitation': check_reuse_intent_limitation()}
    (OUT / 'regression-tests.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS', len(result['installed_regressions_passed']), 'installed regressions; reuse_intent limitation reproduced')
