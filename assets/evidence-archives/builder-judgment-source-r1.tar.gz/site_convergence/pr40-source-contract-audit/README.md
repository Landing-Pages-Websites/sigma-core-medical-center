# PR40 source-contract repair — FAIL CLOSED, uncommitted

Candidate checkout: `peter/sigma-photo-ownership-round1` at `8c077d6e5aeacdab4b5b61d97987c8c05dc40d7a`. Base PR head supplied by the controller: `452fa6f11a2ac76cb1afaed33336e24c7fe1c396`. **No new commit SHA. No source PASS, approval, push, merge, deployment, registry change or Site Review action.**

The worktree contains an auditability repair and a truthful but unresolved handoff. It is not ready to commit. The current research contracts have advanced to different successor implementations. Applying those successors to this older candidate would require composition changes beyond this repair. Relabeling their rejected rasters as approved would invent an asset contract.

## Changed paths

- `src/content/design-assets.ts`: 62 literal runtime URLs, each with the exact source component and section owner. The manifest is actually consumed by the two image helpers, not scanner-only dead code.
- `src/components/batch-three/design-photo.tsx` and `src/components/interior/interior-image.tsx`: replace URL interpolation with manifest resolution. Call-site props, alt/default alt, priority, sizes, fill, wrapper classes and image geometry stay identical. An unknown future asset fails closed instead of escaping the inventory.
- `public/images/design/{about,book,contact,educational-guide,hormone-optimization,neuropathy,pain-relief,pelvic-floor-incontinence,regenerative-medicine,services}/{extraction_plan.json,NOTES.md}`: current research contracts plus explicit PR40 runtime reconciliation. All 59 research frames and 384 original regions, verdicts, mappings, provenance, reuse intent and recipes are preserved. Original expected counts are retained in each frame's reconciliation record. Current original documents are also preserved byte-for-byte under `research-inputs/`.
- `site_convergence/pr40-source-contract-audit/`: commands, input hashes, unchanged-scanner reports, source snapshots, inventories, checks and this record. All reports are confined here.

Only three candidate photo mappings are added, based on the user-directed round2 boundary and byte equality with research `sources/drive/`: About reception-2, About five-chair waiting-room, and Contact waiting-room. They are explicit client-copy deviations from current CODE-only successor frames, not invented extractions or approval claims. About's narrower right-hand photo panel and Contact's native top steps, rail/bracket and 96px desktop gap are preserved. Reuse statements identify each section owner and its narrative purpose; dormant Variant A source references are distinguished from the live home waiting-room occurrence.

No asset was moved or deleted: **all 62 public design PNGs are still referenced by this exact branch**. Archiving any of them would break existing output. All eight already-retired round2 originals remain byte-identical and absent from runtime references. Homepage source, Variant A/B source, Book CSS/header, all existing public assets, external research files and external scanner/test files remain byte-identical to the initial input hashes.

## Exact unbypassed audit result

Every route was audited with the unchanged installed `audit_design_handoff.py`, current research `section_manifest.json` and `composition_map.json`, the in-repo reconciled `extraction_plan.json`, the entire route asset directory, and this repository as `--source-root`. **No `--allow-*` arguments.** `audit-run.json` records each complete argv, shell command, command SHA-256, input SHA-256 values, exit code and report hash. Run `python3 site_convergence/pr40-source-contract-audit/run_audit.py` to reproduce; expected exit is 1.

| Route | Frame contract | Asset mapping | Source references | Asset-role reuse | Duplicate content | Unmapped live rasters |
| --- | --- | --- | --- | --- | --- | ---: |
| about | PASS | FAIL | PASS | PASS | FAIL | 4 |
| book | PASS | FAIL | PASS | PASS | FAIL | 2 |
| contact | PASS | FAIL | PASS | PASS | FAIL | 1 |
| educational-guide | PASS | FAIL | PASS | PASS | FAIL | 4 |
| hormone-optimization | PASS | FAIL | PASS | PASS | FAIL | 6 |
| neuropathy | PASS | FAIL | PASS | PASS | FAIL | 6 |
| pain-relief | PASS | FAIL | PASS | PASS | FAIL | 10 |
| pelvic-floor-incontinence | PASS | PASS | PASS | PASS | FAIL | 0 |
| regenerative-medicine | PASS | FAIL | PASS | PASS | FAIL | 7 |
| services | PASS | FAIL | PASS | PASS | FAIL | 5 |

There are **45 live rasters without authorization in the current CODE source contracts**, not unused files. Their exact filenames, current source components, section owners and byte hashes are in `reconciliation.json`, every route plan's `pr40_reconciliation.unresolved_runtime_conflicts`, and `reports/<slug>.json`. These entries intentionally use `src`/runtime-use records rather than fake `asset_file` mappings. Expected mapped counts cannot honestly equal these runtime counts without a separately authorized source or implementation change.

Four duplicate pairs recur in every report because the unchanged scanner examines the entire source root:

1. `images/design/about/03-facility-gallery-01-real-reception.png` ↔ `images/shared/reception-2.png`.
2. `images/design/about/03-facility-gallery-02-client-waiting-room.png` ↔ `images/design/contact/03-facility-image-01-real-waiting-room.png`.
3. About waiting-room ↔ `images/shared/waiting-room.png`.
4. Contact waiting-room ↔ `images/shared/waiting-room.png`.

All have perceptual distance 0. These are the exact supplied sources, not new generated photos. The reception shared occurrence is dormant Variant A source; the shared waiting-room has both dormant Variant A and live home source references. Those sources were not edited or excluded. The installed scanner does not read plan `reuse_intent`, and its duplicate routine only accepts CLI exemptions. A bounded regression reproduces that limitation. No exemption, scanner patch, alternate audit or asset deletion was used to manufacture a PASS. Controller reconciliation of the 45 source/runtime conflicts and scanner support for explicit per-use reuse contracts remain necessary before this candidate can pass as requested.

## Verification and limitations

- Real local `npm ci --ignore-scripts --no-audit --no-fund` setup; `npm run build`, `npm run lint`, and `git diff --check` PASS. No dependencies or symlinks are tracked. Commands, hashes, environment versions and log hashes are in `verification.json`.
- All 13 installed scanner regression tests PASS using stdlib/Pillow and temporary fixtures confined to this report directory. External scanner files are unchanged. The added limitation fixture confirms that documented reuse intent is ignored.
- All 62 generated URLs equal their original interpolation output and resolve to existing unchanged assets. 124 direct before/after helper renders match, including default/custom alt, classes and priority. The live manifest matches every literal and data-driven component use.
- All 19 generated pages have identical non-script/non-link DOM elements, attributes and text before/after. Image URL/srcset, alt, sizes, fill styling, section geometry classes, status copy and robots metadata match. Book, educational guide and all four legal/accessibility utilities retain `noindex, follow`. Contact has no robots meta in this baseline; the inherited successor NOTES statement that Contact is noindex does not describe this candidate and must not be treated as proof.
- No painted browser comparison or new visual approval was performed. This is an invisible source-audit refactor. Existing round2 browser/bootstrap and visual-review limitations remain unresolved.
- Self-review verified the limited helper diff, explicit manifest coverage, original research preservation, asset hashes and protected scope. The `simplify` executable/skill was unavailable; no commit gate was bypassed because no commit was attempted.

The earlier round2 statement about four structural audit passes is historical evidence, not the verdict for today's research inputs. The reports here are the current fail-closed result.
