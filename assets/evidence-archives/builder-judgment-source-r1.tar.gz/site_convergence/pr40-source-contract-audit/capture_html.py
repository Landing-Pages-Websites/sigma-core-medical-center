"""Compare prerendered image attributes, section structure, text and noindex states."""
import json
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


class Surface(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ignored = 0
        self.elements = []
        self.text = []
        self.images = []
        self.robots = []

    def handle_starttag(self, tag, attrs):
        if tag in ('script',):
            self.ignored += 1
        if self.ignored or tag == 'link':
            return
        self.elements.append([tag, attrs])
        if tag == 'img':
            self.images.append(dict(attrs))
        if tag == 'meta' and dict(attrs).get('name') == 'robots':
            self.robots.append(dict(attrs)['content'])

    def handle_endtag(self, tag):
        if tag == 'script':
            self.ignored -= 1
        elif not self.ignored:
            self.elements.append(['/' + tag, []])

    def handle_data(self, data):
        if not self.ignored and data.strip():
            self.text.append(data)


def capture():
    pages = {}
    for path in sorted((ROOT / '.next/server/app').rglob('*.html')):
        parser = Surface()
        parser.feed(path.read_text())
        pages[str(path.relative_to(ROOT / '.next/server/app'))] = {
            'elements': parser.elements, 'text': parser.text,
            'images': parser.images, 'robots': parser.robots}
    return pages


if __name__ == '__main__':
    data = capture()
    destination = OUT / f'html-{sys.argv[1]}.json'
    destination.write_text(json.dumps(data, indent=2) + '\n')
    if sys.argv[1] == 'after':
        before = json.loads((OUT / 'html-before.json').read_text())
        after = json.loads(destination.read_text())
        diff = [key for key in before.keys() | data.keys() if before.get(key) != after.get(key)]
        result = {'status': 'PASS' if not diff else 'FAIL', 'changed_pages': diff, 'pages_checked': len(data),
                  'comparison': 'All non-script/non-link DOM elements, attributes, text, image attributes and robots metadata.'}
        (OUT / 'html-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
        print(result)
        assert not diff, diff
    else:
        print('Captured', len(data), 'baseline pages')
