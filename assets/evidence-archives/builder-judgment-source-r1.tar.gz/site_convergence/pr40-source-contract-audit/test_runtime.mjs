import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import ts from 'typescript';
import * as jsxRuntime from 'react/jsx-runtime';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const out = path.dirname(fileURLToPath(import.meta.url));

function load(source, manifest) {
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
  }).outputText;
  const exports = {};
  vm.runInNewContext(compiled, {
    exports,
    require: (name) => {
      if (name === '@/content/design-assets') return manifest;
      if (name === 'next/image') return { __esModule: true, default: 'Image' };
      if (name === 'react/jsx-runtime') return jsxRuntime;
      throw new Error(`Unexpected test import: ${name}`);
    },
  });
  return exports;
}

function checkHelpers(manifest, uses) {
  const helpers = [
    ['src/components/batch-three/design-photo.tsx', 'DesignPhoto', ['about', 'book', 'contact', 'educational-guide']],
    ['src/components/interior/interior-image.tsx', 'InteriorImage', ['services', 'neuropathy', 'pain-relief', 'hormone-optimization', 'pelvic-floor-incontinence', 'regenerative-medicine']],
  ];
  let count = 0;
  for (const [path, name, slugs] of helpers) {
    const before = load(execFileSync('git', ['show', `HEAD:${path}`], { encoding: 'utf8' }))[name];
    const after = load(fs.readFileSync(path, 'utf8'), manifest)[name];
    for (const use of uses.filter((item) => slugs.includes(item.key.split('/')[0]))) {
      const [slug, file] = use.key.split('/');
      for (const extra of [{}, { alt: 'Exact alternative text', className: 'exact-class', priority: true }]) {
        const props = { slug, file, ...extra };
        assert.equal(JSON.stringify(after(props)), JSON.stringify(before(props)));
        count++;
      }
    }
  }
  return count;
}

const manifest = load(fs.readFileSync('src/content/design-assets.ts', 'utf8'));
const uses = JSON.parse(fs.readFileSync(`${out}/runtime-uses.json`, 'utf8'));
assert.equal(Object.keys(manifest.DESIGN_ASSETS).length, uses.length);
for (const use of uses) {
  const [slug, file] = use.key.split('/');
  assert.equal(manifest.designAssetSrc(slug, file), `/images/design/${slug}/${file}`);
  assert.equal(manifest.DESIGN_ASSETS[use.key].sourceComponent, use.sourceComponent);
  assert.equal(manifest.DESIGN_ASSETS[use.key].sectionOwner, use.sectionOwner);
}
assert.throws(() => manifest.designAssetSrc('about', 'uncontracted.png'), /Missing design asset source contract/);
const result = { status: 'PASS', literalUrls: uses.length, equivalentHelperRenders: checkHelpers(manifest, uses), unmappedAssetFailsClosed: true };
fs.writeFileSync(`${out}/runtime-tests.json`, JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify(result) + '\n');
