"""Preserve current research contracts; disclose bounded PR40 deviations and conflicts."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RESEARCH = Path('/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a')
USES = json.loads((OUT / 'runtime-uses.json').read_text())
CLIENT_USES = {
    'about/03-facility-gallery-01-real-reception.png': ('reception-2.png', 'Reception identity in the About facility gallery; no broader room, provider or address is implied.'),
    'about/03-facility-gallery-02-client-waiting-room.png': ('waiting-room.png', 'Five-chair waiting-room view in the right-hand gallery panel, replacing the unsupplied broad panorama.'),
    'contact/03-facility-image-01-real-waiting-room.png': ('waiting-room.png', 'Authentic facility orientation beneath the Contact caveat, native top steps, rail/bracket and 96px desktop bottom gap; not location verification.'),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def shared_disclosure(source):
    shared = ROOT / 'public/images/shared' / source
    references = []
    for component in sorted((ROOT / 'src/components').rglob('*.tsx')):
        for number, line in enumerate(component.read_text().splitlines(), 1):
            if f'/images/shared/{source}' in line:
                references.append({'source_component': str(component.relative_to(ROOT)), 'line': number,
                    'section_owner': 'place-of-care' if component.stem == 'place-of-care' else 'site-footer',
                    'runtime_status': 'live on /' if '/variant-b/' in str(component) else 'dormant source; /variant-a returns notFound',
                    'reuse_intent': 'Source occurrence disclosed for completeness, not approved or exempted by this repair.'})
    return {'path': str(shared.relative_to(ROOT)), 'sha256': sha(shared), 'source_occurrences': references}


def client_region(use):
    source, job = CLIENT_USES[use['key']]
    original = RESEARCH / 'sources/drive' / source
    runtime = ROOT / 'public' / use['src'].lstrip('/')
    assert sha(original) == sha(runtime)
    intent = ('This section uses the same supplied waiting-room view as About gallery, Contact facility and the live home place-of-care section. '
              'About inventories the two distinct supplied room views; Contact orients the visit-status section; Home introduces the place of care. '
              'Reuse conveys the same room and never a second location or a verified address.') if source == 'waiting-room.png' else (
              'This About gallery occurrence identifies the supplied reception-2 view once. The shared reception-2 path remains in dormant Variant A source; '
              'that occurrence is disclosed, not a new placement or a same-page repetition approved here.')
    return {'id': 'pr40-client-' + source.removesuffix('.png'), 'verdict': 'extract',
        'asset_file': Path(use['key']).name, 'section_owner': use['sectionOwner'], 'asset_scope': 'section',
        'source': 'client-copy', 'source_provenance': str(original), 'source_sha256': sha(original),
        'source_component': use['sourceComponent'], 'narrative_job': job, 'treatment': 'framed',
        'reuse_intent': f"Owner {use['sectionOwner']} in {use['sourceComponent']}: {job} {intent}",
        'deviation_basis': 'docs/pr40-round2-photo-role.md and the current user-directed bounded PR40 candidate; not successor-frame approval.',
        'explicit_deviation': 'Current research successor region verdicts remain CODE. This additional client-copy region discloses the retained PR40 photo; it is not an extraction from that successor frame.',
        'presentation': {'crop_contract': 'Preserve current b3 geometry and object-cover crop. No new crop or broader scene is authorized.',
                         'source_provenance': str(original)}, 'shared_source_disclosure': shared_disclosure(source)}


def reconcile_frame(slug, frame):
    owner = frame['frame'].removesuffix('.png')
    uses = [u for u in USES if u['key'].startswith(slug + '/') and u['sectionOwner'] == owner]
    inherited = {r['asset_file'] for r in frame['regions'] if r.get('asset_file') and r.get('verdict') != 'code'}
    source_count = frame.get('expected_asset_count', len(inherited))
    for use in uses:
        if use['key'] in CLIENT_USES:
            frame['regions'].append(client_region(use))
    mapped = {r['asset_file'] for r in frame['regions'] if r.get('asset_file') and r.get('verdict') != 'code'}
    conflicts = []
    for use in uses:
        if Path(use['key']).name not in mapped:
            conflicts.append({**use, 'issue': 'Runtime still renders this legacy raster; the current research contract assigns CODE and supplies no asset_file authorization. Preserved in public because it remains referenced. Do not relabel as approved.',
                'sha256': sha(ROOT / 'public' / use['src'].lstrip('/'))})
    frame['expected_asset_count'] = len(mapped)
    frame['pr40_reconciliation'] = {'research_expected_asset_count': source_count,
        'runtime_asset_count': len(uses), 'runtime_uses': uses, 'unresolved_runtime_conflicts': conflicts,
        'status': 'FAIL_SOURCE_CONTRACT' if conflicts else 'RECONCILED_CANDIDATE_ONLY'}
    return conflicts


def reconcile_route(source):
    slug = source.parent.name
    plan = json.loads(source.read_text())
    original = copy.deepcopy(plan)
    conflicts = [c for f in plan['frames'] for c in reconcile_frame(slug, f)]
    evidence = OUT / 'research-inputs' / slug
    evidence.mkdir(parents=True, exist_ok=True)
    for name in ('extraction_plan.json', 'NOTES.md'):
        (evidence / name).write_bytes((source.parent / name).read_bytes())
    plan['pr40_source_contract'] = {'status': 'FAIL_SOURCE_CONTRACT' if conflicts else 'RECONCILED_CANDIDATE_ONLY',
        'research_source': str(source), 'research_sha256': sha(source),
        'research_snapshot': str((evidence / source.name).relative_to(ROOT)),
        'authority': 'Current research frames/regions/verdicts are retained. Only the three exact client-copy uses in the round2 record are added as explicit candidate deviations. Unmapped runtime rasters are conflicts, not approved mappings.',
        'research_top_level_counts': {k: original[k] for k in ('expected_asset_count', 'raster_assets', 'owned_raster_count') if k in original},
        'expected_asset_count': sum(f['expected_asset_count'] for f in plan['frames']),
        'runtime_asset_count': sum(f['pr40_reconciliation']['runtime_asset_count'] for f in plan['frames']),
        'unresolved_runtime_conflicts': len(conflicts),
        'upstream_scope': 'Inherited zero-photo constraints, summaries, review claims and recipes describe the external successor, not this PR40 runtime. No approval status is promoted.',
        'archive_disposition': 'All 62 public design PNGs are currently referenced. No image was deleted or moved. Eight round2 retired originals remain in assets/retired-photo-roles, unreferenced by runtime.'}
    destination = ROOT / 'public/images/design' / slug
    write_json(destination / source.name, plan)
    write_notes(destination, source.parent / 'NOTES.md', plan)
    return {'slug': slug, **plan['pr40_source_contract'], 'conflicts': conflicts}


def write_notes(destination, source, plan):
    record = plan['pr40_source_contract']
    lines = ['# PR40 candidate source-contract reconciliation', '',
        'This in-repo handoff describes the requested branch. It is builder-owned evidence, not approval or a source PASS.',
        f"Research input: `{source}` (SHA-256 `{sha(source)}`).", '',
        f"Mapped candidate assets: {record['expected_asset_count']}; runtime assets: {record['runtime_asset_count']}; unresolved CODE/raster conflicts: {record['unresolved_runtime_conflicts']}.",
        'Every original research frame, region, verdict, asset_file, provenance and recipe is preserved. Added client-copy regions are explicit round2 deviations, not successor-frame extractions.',
        'Inherited research notes below describe their own successor checkout. Their zero-runtime/approval/review statements do not establish facts about this PR40 candidate.', '',
        'The scanner ignores reuse_intent and requires forbidden CLI exemptions for duplicates. Its unbypassed result remains authoritative; this document grants no exemption.', '']
    for frame in plan['frames']:
        reconciliation = frame['pr40_reconciliation']
        lines.append(f"- `{frame['frame']}`: source expects {reconciliation['research_expected_asset_count']}, candidate maps {frame['expected_asset_count']}, runtime uses {reconciliation['runtime_asset_count']}.")
        for conflict in reconciliation['unresolved_runtime_conflicts']:
            lines.append(f"  - UNRESOLVED `{conflict['key']}` in `{conflict['sourceComponent']}`: research requires CODE; still rendered. No fake asset_file was added.")
        for region in frame['regions']:
            if str(region['id']).startswith('pr40-client-'):
                lines.append(f"  - CLIENT COPY `{region['asset_file']}`: {region['narrative_job']} Reuse: {region['reuse_intent']}")
    lines.extend(['', '## Preserved research NOTES.md (upstream scope only)', '', source.read_text().rstrip(), ''])
    (destination / 'NOTES.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    records = [reconcile_route(p) for p in sorted((RESEARCH / 'design_assets/pages').glob('*/extraction_plan.json'))]
    write_json(OUT / 'reconciliation.json', records)
    print([(r['slug'], r['expected_asset_count'], r['runtime_asset_count'], r['unresolved_runtime_conflicts']) for r in records])
