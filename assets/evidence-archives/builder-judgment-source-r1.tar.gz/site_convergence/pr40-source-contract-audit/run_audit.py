"""Run the unchanged external CLI with current plans and no allow arguments."""
import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RESEARCH = Path('/var/lib/megaclaw/workspace/website-lp-build-research-data/b380819e-88b6-48bd-8f1e-bfe6a580d72a')
SCANNER = Path('/var/lib/megaclaw/workspace/skills/website-orchestrator/scripts/audit_design_handoff.py')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_route(slug):
    refs = RESEARCH / 'design_refs/pages' / slug
    plan = ROOT / 'public/images/design' / slug / 'extraction_plan.json'
    report = OUT / 'reports' / f'{slug}.json'
    args = [sys.executable, str(SCANNER), '--manifest', str(refs / 'section_manifest.json'),
        '--composition-map', str(refs / 'composition_map.json'), '--extraction-plan', str(plan),
        '--assets-dir', str(plan.parent), '--source-root', str(ROOT), '--out', str(report), '--check']
    result = subprocess.run(args, capture_output=True, text=True, cwd=ROOT, timeout=90)
    (OUT / 'reports' / f'{slug}.log').write_text(result.stdout + result.stderr)
    payload = json.loads(report.read_text())
    inputs = [SCANNER, SCANNER.with_name('design_handoff_schema.py'), refs / 'section_manifest.json', refs / 'composition_map.json', plan]
    record = {'slug': slug, 'argv': args, 'command': shlex.join(args), 'command_sha256': hashlib.sha256(shlex.join(args).encode()).hexdigest(), 'exit_code': result.returncode,
        'input_sha256': {str(path): sha(path) for path in inputs}, 'report_sha256': sha(report),
        'status': payload['status'], 'checks': payload['checks'], 'issues': payload['issues']}
    print(slug, payload['checks'], flush=True)
    return record


if __name__ == '__main__':
    (OUT / 'reports').mkdir(exist_ok=True)
    results = [run_route(p.parent.name) for p in sorted((ROOT / 'public/images/design').glob('*/extraction_plan.json'))]
    sources = [p for root in ('src', 'app') for p in (ROOT / root).rglob('*') if p.is_file()]
    assets = [p for p in (ROOT / 'public/images').rglob('*') if p.is_file()]
    payload = {'status': 'PASS' if all(r['status'] == 'PASS' for r in results) else 'FAIL',
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'audit_driver_sha256': sha(Path(__file__).resolve()),
        'worktree_source_and_asset_sha256': {str(p.relative_to(ROOT)): sha(p) for p in sources + assets},
        'routes': results}
    (OUT / 'audit-run.json').write_text(json.dumps(payload, indent=2) + '\n')
    sys.exit(0 if payload['status'] == 'PASS' else 1)
