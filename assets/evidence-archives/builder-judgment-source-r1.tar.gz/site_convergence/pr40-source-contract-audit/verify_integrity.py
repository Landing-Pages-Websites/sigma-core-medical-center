"""Check source preservation, explicit-use coverage and unchanged protected surfaces."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BEFORE = json.loads((OUT / 'inputs-before.json').read_text())['sha256']
USES = json.loads((OUT / 'runtime-uses.json').read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_runtime_inventory():
    observed = []
    for path in sorted((ROOT / 'src/components').rglob('*.tsx')):
        text = path.read_text()
        for slug, file in re.findall(r'slug="([^"]+)" file="([^"]+)"', text):
            observed.append((slug + '/' + file, str(path.relative_to(ROOT))))
        for file in re.findall(r'file: "([^"]+\.png)"', text):
            observed.append((path.parent.name + '/' + file, str(path.relative_to(ROOT))))
    assert sorted(observed) == sorted((u['key'], u['sourceComponent']) for u in USES)
    assert len(observed) == len(set(observed)), 'Same-page repeat requires explicit audit'
    assets = sorted(str(p.relative_to(ROOT / 'public/images/design')) for p in (ROOT / 'public/images/design').glob('*/*.png'))
    assert assets == sorted(u['key'] for u in USES), 'Shipped/inventory mismatch'
    return {'explicit_uses': len(observed), 'all_shipped_design_images_referenced': True}


def verify_source_preservation():
    frame_count = region_count = 0
    for source in sorted((OUT / 'research-inputs').glob('*/extraction_plan.json')):
        original = json.loads(source.read_text())
        local = json.loads((ROOT / 'public/images/design' / source.parent.name / source.name).read_text())
        for key, value in original.items():
            if key != 'frames':
                assert local[key] == value, (source.parent.name, key)
        assert len(original['frames']) == len(local['frames'])
        for old_frame, new_frame in zip(original['frames'], local['frames']):
            for key, value in old_frame.items():
                if key not in ('regions', 'expected_asset_count'):
                    assert new_frame[key] == value
            assert new_frame['regions'][:len(old_frame['regions'])] == old_frame['regions']
            if 'expected_asset_count' in old_frame:
                assert new_frame['pr40_reconciliation']['research_expected_asset_count'] == old_frame['expected_asset_count']
            frame_count += 1
            region_count += len(old_frame['regions'])
    return {'research_frames_preserved': frame_count, 'research_regions_preserved': region_count}


def verify_scope():
    allowed = {'src/components/batch-three/design-photo.tsx', 'src/components/interior/interior-image.tsx'}
    changed = []
    for name, expected in BEFORE.items():
        path = Path(name) if name.startswith('/') else ROOT / name
        if not path.is_file() or digest(path) != expected:
            changed.append(name)
    assert set(changed) == allowed, changed
    retired = list((ROOT / 'assets/retired-photo-roles').glob('*/*.png'))
    assert len(retired) == 8
    keys = {use['key'] for use in USES}
    assert all('/'.join(p.parts[-2:]) not in keys for p in retired)
    assert (ROOT / 'node_modules').is_dir() and not (ROOT / 'node_modules').is_symlink()
    return {'changed_existing_inputs': sorted(changed), 'retired_originals_preserved_and_unreferenced': len(retired),
        'external_research_and_scanner_unchanged': True, 'homepage_routes_and_variants_unchanged': True,
        'all_original_public_assets_unchanged': True, 'real_local_node_modules': True}


if __name__ == '__main__':
    result = {'status': 'PASS', **verify_runtime_inventory(), **verify_source_preservation(), **verify_scope()}
    diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
    assert diff.returncode == 0, diff.stdout + diff.stderr
    result['git_diff_check'] = 'PASS'
    (OUT / 'integrity.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
